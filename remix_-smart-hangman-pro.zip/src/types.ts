// src/types.ts

export type Difficulty = 'easy' | 'medium' | 'hard';

export interface WordItem {
  word: string;
  hint: string;
}

export interface UserRecord {
  user_id: number;
  username: string;
  password_hash: string;
  created_at: string;
}

export interface ScoreRecord {
  score_id: number;
  user_id: number;
  score: number;
  category: string;
  difficulty: string;
  words_guessed: number;
  played_at: string;
}

export interface PunishmentRecord {
  punishment_id: number;
  user_id: number;
  username: string;
  punishment_type: string;
  challenge_desc: string;
  status: 'PENDING' | 'REDEEMED';
  created_at: string;
  redeemed_at?: string;
}

export interface DatabaseState {
  users: UserRecord[];
  scores: ScoreRecord[];
  punishments?: PunishmentRecord[];
}
