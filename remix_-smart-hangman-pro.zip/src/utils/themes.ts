// src/utils/themes.ts

export interface AppTheme {
  id: string;
  name: string;
  icon: string;
  bgScreen: string;       // Outer body background
  bgCard: string;         // Component panels and headers
  bgInner: string;        // Inner boxes, terminal output, input wells
  border: string;          // Default borders
  borderHover: string;     // Hovered border highlight
  textAccent: string;      // Glow text accents (cyan, purple, emerald, etc)
  bgAccent: string;        // Active background buttons
  bgAccentHover: string;   // Active button hovers
  accentShadow: string;    // Glowing drop shadow for active elements
  gradientAccent: string;  // Multi-color linear gradients (e.g. headers and buttons)
  badgeBg: string;         // Highlighted tags bg
  badgeText: string;       // Highlighted tags text
  keyboardActive: string;  // Keyboard guessed-correct keys
  rawColor: string;        // Raw Hex color for SVG strokes and canvas components
}

export const APP_THEMES: AppTheme[] = [
  {
    id: 'slate-cyber',
    name: 'Classic Obsidian',
    icon: '💻',
    bgScreen: 'bg-slate-950 text-slate-100',
    bgCard: 'bg-slate-900 border-slate-800/80',
    bgInner: 'bg-slate-950/80 border-slate-850',
    border: 'border-slate-800/85',
    borderHover: 'hover:border-slate-700/80',
    textAccent: 'text-cyan-400',
    bgAccent: 'bg-cyan-500 text-slate-950',
    bgAccentHover: 'hover:bg-cyan-400',
    accentShadow: 'shadow-cyan-500/10',
    gradientAccent: 'from-cyan-500 via-sky-500 to-indigo-500',
    badgeBg: 'bg-indigo-950/80 border-indigo-900/60',
    badgeText: 'text-indigo-400',
    keyboardActive: 'bg-emerald-500 text-slate-950',
    rawColor: '#22d3ee'
  },
  {
    id: 'cosmic-amethyst',
    name: 'Cosmic Amethyst',
    icon: '🔮',
    bgScreen: 'bg-zinc-950 text-zinc-100',
    bgCard: 'bg-[#120a24] border-purple-950/80',
    bgInner: 'bg-[#0a0518] border-purple-900/40',
    border: 'border-purple-900/40',
    borderHover: 'hover:border-purple-700/60',
    textAccent: 'text-fuchsia-400',
    bgAccent: 'bg-fuchsia-500 text-slate-950',
    bgAccentHover: 'hover:bg-fuchsia-400',
    accentShadow: 'shadow-fuchsia-500/15',
    gradientAccent: 'from-fuchsia-500 via-purple-500 to-violet-500',
    badgeBg: 'bg-purple-950/80 border-purple-900/60',
    badgeText: 'text-purple-300',
    keyboardActive: 'bg-fuchsia-500 text-slate-950',
    rawColor: '#e879f9'
  },
  {
    id: 'emerald-matrix',
    name: 'Emerald Matrix',
    icon: '🐍',
    bgScreen: 'bg-neutral-950 text-emerald-50',
    bgCard: 'bg-[#061e1b] border-emerald-950/80',
    bgInner: 'bg-[#02100e] border-emerald-900/40',
    border: 'border-emerald-900/40',
    borderHover: 'hover:border-emerald-700/60',
    textAccent: 'text-emerald-400',
    bgAccent: 'bg-emerald-500 text-slate-950',
    bgAccentHover: 'hover:bg-emerald-400',
    accentShadow: 'shadow-emerald-500/15',
    gradientAccent: 'from-emerald-500 via-teal-500 to-cyan-500',
    badgeBg: 'bg-teal-950/80 border-teal-900/60',
    badgeText: 'text-teal-300',
    keyboardActive: 'bg-emerald-500 text-slate-950',
    rawColor: '#34d399'
  },
  {
    id: 'crimson-nebula',
    name: 'Crimson Nebula',
    icon: '💥',
    bgScreen: 'bg-stone-950 text-red-50',
    bgCard: 'bg-[#1f0b0f] border-red-950/80',
    bgInner: 'bg-[#0f0406] border-red-900/40',
    border: 'border-red-900/40',
    borderHover: 'hover:border-red-700/60',
    textAccent: 'text-rose-400',
    bgAccent: 'bg-rose-500 text-slate-950',
    bgAccentHover: 'hover:bg-rose-400',
    accentShadow: 'shadow-rose-500/15',
    gradientAccent: 'from-rose-500 via-red-500 to-amber-500',
    badgeBg: 'bg-rose-950/80 border-rose-900/60',
    badgeText: 'text-rose-300',
    keyboardActive: 'bg-rose-500 text-slate-950',
    rawColor: '#fb7185'
  },
  {
    id: 'tokyo-neon',
    name: 'Tokyo Sunset',
    icon: '🌅',
    bgScreen: 'bg-slate-950 text-orange-50',
    bgCard: 'bg-[#0b132b] border-blue-950/80',
    bgInner: 'bg-[#050a18] border-indigo-950/50',
    border: 'border-indigo-950/50',
    borderHover: 'hover:border-indigo-800/50',
    textAccent: 'text-amber-400',
    bgAccent: 'bg-amber-500 text-slate-950',
    bgAccentHover: 'hover:bg-amber-400',
    accentShadow: 'shadow-amber-500/15',
    gradientAccent: 'from-amber-500 via-orange-500 to-rose-500',
    badgeBg: 'bg-indigo-950/80 border-indigo-900/60',
    badgeText: 'text-indigo-300',
    keyboardActive: 'bg-amber-500 text-slate-950',
    rawColor: '#fbbf24'
  }
];
