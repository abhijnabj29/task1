// src/utils/dbMock.ts
import { UserRecord, ScoreRecord, DatabaseState, PunishmentRecord } from '../types';

const STORAGE_KEY = 'smarthangman_mock_db';

// Static seed data matching schema.sql exactly
const INITIAL_USERS: UserRecord[] = [
  {
    user_id: 1,
    username: 'SpeedyGuesser',
    password_hash: '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64', // 'pass123' representation
    created_at: '2026-06-15 10:00:00',
  },
  {
    user_id: 2,
    username: 'TechWizard',
    password_hash: '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64', // 'pass123'
    created_at: '2026-06-15 11:00:00',
  },
  {
    user_id: 3,
    username: 'HangmanPro',
    password_hash: '240753d4c0628e4e9b959be70ae2a2a2f7cf40212a21e4001946c59d914fa64bb', // 'admin123'
    created_at: '2026-06-16 08:00:00',
  }
];

const INITIAL_SCORES: ScoreRecord[] = [
  { score_id: 1, user_id: 1, score: 450, category: 'Technology', difficulty: 'easy', words_guessed: 4, played_at: '2026-06-15 10:30:00' },
  { score_id: 2, user_id: 1, score: 900, category: 'Technology', difficulty: 'medium', words_guessed: 5, played_at: '2026-06-15 11:45:00' },
  { score_id: 3, user_id: 2, score: 1200, category: 'Technology', difficulty: 'hard', words_guessed: 3, played_at: '2026-06-16 08:15:00' },
  { score_id: 4, user_id: 2, score: 600, category: 'Animals', difficulty: 'medium', words_guessed: 3, played_at: '2026-06-16 09:00:00' },
  { score_id: 5, user_id: 3, score: 1600, category: 'Sports', difficulty: 'hard', words_guessed: 4, played_at: '2026-06-16 11:10:00' },
  { score_id: 6, user_id: 3, score: 300, category: 'Movies', difficulty: 'easy', words_guessed: 3, played_at: '2026-06-16 11:40:00' }
];

const INITIAL_PUNISHMENTS: PunishmentRecord[] = [
  {
    punishment_id: 1,
    user_id: 1,
    username: 'SpeedyGuesser',
    punishment_type: 'apology',
    challenge_desc: 'Type: My ortho-decryption collapsed, spare the gallows!',
    status: 'REDEEMED',
    created_at: '2026-06-15 10:35:00',
    redeemed_at: '2026-06-15 10:37:00'
  }
];

export function getDatabaseState(): DatabaseState {
  try {
    const dataString = localStorage.getItem(STORAGE_KEY);
    if (dataString) {
      const parsed = JSON.parse(dataString);
      if (!parsed.punishments) {
        parsed.punishments = INITIAL_PUNISHMENTS;
        saveDatabaseState(parsed);
      }
      return parsed;
    }
  } catch (e) {
    console.error("Local storage read error, defaulting seeds: ", e);
  }
  
  const defaultState = { users: INITIAL_USERS, scores: INITIAL_SCORES, punishments: INITIAL_PUNISHMENTS };
  saveDatabaseState(defaultState);
  return defaultState;
}

export function saveDatabaseState(state: DatabaseState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Could not persist database state: ", e);
  }
}

// Simple deterministic hash matching Python hashlib.sha256 in length/nature for mockup UI
export function simpleSha256(text: string): string {
  // Simple custom browser hash generator to represent password encryption visually
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padEnd(8, '7');
  return `mock_sha256_${hex}_${text.length * 99}`.padEnd(64, '0');
}

export function registerUserInMockDB(username: string, passwordPlain: string): { success: boolean; message: string } {
  const state = getDatabaseState();
  const trimmedUser = username.trim();
  
  if (trimmedUser.length < 3) return { success: false, message: "Username must be at least 3 characters." };
  if (passwordPlain.length < 4) return { success: false, message: "Password must be at least 4 characters." };
  
  const lowercaseMatch = state.users.some(u => u.username.toLowerCase() === trimmedUser.toLowerCase());
  if (lowercaseMatch) {
    return { success: false, message: `Error 1062 (23000): Duplicate entry '${trimmedUser}' for key 'users.username'` };
  }
  
  const newUser_id = state.users.reduce((max, u) => Math.max(max, u.user_id), 0) + 1;
  const hash = simpleSha256(passwordPlain);
  const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ');
  
  const newUserObj: UserRecord = {
    user_id: newUser_id,
    username: trimmedUser,
    password_hash: hash,
    created_at: nowStr
  };
  
  state.users.push(newUserObj);
  saveDatabaseState(state);
  return { success: true, message: "User created and database updated successfully!" };
}

export function authenticateUserInMockDB(username: string, passwordPlain: string): { success: boolean; message: string; user?: { user_id: number; username: string } } {
  const state = getDatabaseState();
  const trimmedUser = username.trim();
  const hashVal = simpleSha256(passwordPlain);
  
  // Custom bypass for seeds to match hardcoded sha256 exactly
  const seedBypassMatch = state.users.find(u => {
    if (u.username.toLowerCase() === trimmedUser.toLowerCase()) {
      if (passwordPlain === 'pass123' && u.password_hash === '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64') return true;
      if (passwordPlain === 'admin123' && u.password_hash === '240753d4c0628e4e9b959be70ae2a2a2f7cf40212a21e4001946c59d914fa64bb') return true;
      return u.password_hash === hashVal;
    }
    return false;
  });

  if (seedBypassMatch) {
    return {
      success: true,
      message: "Credentials accepted.",
      user: { user_id: seedBypassMatch.user_id, username: seedBypassMatch.username }
    };
  }
  
  return { success: false, message: "Error: Invalid username or password." };
}

export function recordScoreInMockDB(user_id: number, score: number, category: string, difficulty: string, wordsGuessed: number): boolean {
  const state = getDatabaseState();
  const newScoreId = state.scores.reduce((max, s) => Math.max(max, s.score_id), 0) + 1;
  const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ');

  const newScoreObj: ScoreRecord = {
    score_id: newScoreId,
    user_id,
    score,
    category,
    difficulty,
    words_guessed: wordsGuessed,
    played_at: nowStr
  };

  state.scores.push(newScoreObj);
  saveDatabaseState(state);
  return true;
}

export function getGlobalLeaderboardFromMockDB(limit = 10) {
  const state = getDatabaseState();
  return state.scores
    .map(score => {
      const userObj = state.users.find(u => u.user_id === score.user_id);
      return {
        username: userObj ? userObj.username : 'Unknown_Guest',
        score: score.score,
        category: score.category,
        difficulty: score.difficulty,
        words_guessed: score.words_guessed,
        played_at: score.played_at
      };
    })
    .sort((a, b) => b.score - a.score || new Date(a.played_at).getTime() - new Date(b.played_at).getTime())
    .slice(0, limit);
}

export function getUserAnalyticsFromMockDB(user_id: number) {
  const state = getDatabaseState();
  const playerScores = state.scores.filter(s => s.user_id === user_id);
  
  if (playerScores.length === 0) {
    return {
      total_games: 0,
      total_score: 0,
      avg_score: 0,
      total_words_guessed: 0,
      preferred_category: "N/A"
    };
  }

  const totalScore = playerScores.reduce((sum, s) => sum + s.score, 0);
  const totalWords = playerScores.reduce((sum, s) => sum + s.words_guessed, 0);
  const avg = Math.round((totalScore / playerScores.length) * 10) / 10;
  
  // Calculate preferred category
  const categoriesMap: { [key: string]: number } = {};
  playerScores.forEach(s => {
    categoriesMap[s.category] = (categoriesMap[s.category] || 0) + 1;
  });
  
  let preferredCat = "N/A";
  let maxCount = -1;
  Object.keys(categoriesMap).forEach(cat => {
    if (categoriesMap[cat] > maxCount) {
      maxCount = categoriesMap[cat];
      preferredCat = cat;
    }
  });

  return {
    total_games: playerScores.length,
    total_score: totalScore,
    avg_score: avg,
    total_words_guessed: totalWords,
    preferred_category: preferredCat
  };
}

// Visual mini SQL engine interpreter to execute simulated queries in our browser terminal!
export function interpretSQLMock(sqlQuery: string): { columns: string[]; rows: any[]; error?: string } {
  const cleanQ = sqlQuery.trim().replace(/;$/, '').trim();
  const state = getDatabaseState();

  if (!cleanQ) {
    return { columns: [], rows: [], error: "No statements parsed." };
  }

  // Parse queries like SELECT
  const selectRegex = /^SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$/i;
  const match = cleanQ.match(selectRegex);

  if (!match) {
    // Check if it is a write query
    if (/^INSERT/i.test(cleanQ)) {
      return { columns: [], rows: [], error: "Executing INSERT commands directly via command terminal is protected. Use the Register dashboard instead." };
    }
    if (/^UPDATE/i.test(cleanQ) || /^DELETE/i.test(cleanQ)) {
      return { columns: [], rows: [], error: "DDL / DML modifications are protected under smart schemas protection policies." };
    }
    return { columns: [], rows: [], error: "Invalid SQL syntax. Executable templates: SELECT * FROM users; or SELECT * FROM scores; options supported." };
  }

  const [, fieldsSelected, tableName, whereClause, orderByClause, limitCount] = match;
  let targetCollection: any[] = [];

  if (tableName.toLowerCase() === "users") {
    targetCollection = JSON.parse(JSON.stringify(state.users));
  } else if (tableName.toLowerCase() === "scores") {
    targetCollection = JSON.parse(JSON.stringify(state.scores));
  } else if (tableName.toLowerCase() === "punishments") {
    targetCollection = JSON.parse(JSON.stringify(state.punishments || []));
  } else {
    return { columns: [], rows: [], error: `Table 'smarthangman_db.${tableName}' doesn't exist` };
  }

  // Apply visual where filters
  if (whereClause) {
    // Simplistic WHERE filter evaluation
    const eqMatch = whereClause.match(/(\w+)\s*=\s*(.+)/i);
    if (eqMatch) {
      const [, col, valRaw] = eqMatch;
      const cleanVal = valRaw.trim().replace(/^['"]|['"]$/g, '');
      targetCollection = targetCollection.filter(row => {
        const rowVal = String(row[col.toLowerCase().trim()]);
        return rowVal.toLowerCase() === cleanVal.toLowerCase();
      });
    }
  }

  // Apply sorting
  if (orderByClause) {
    const ascDesc = /desc/i.test(orderByClause) ? -1 : 1;
    const colName = orderByClause.split(/\s+/)[0].trim().toLowerCase();
    targetCollection.sort((a, b) => {
      const valA = a[colName];
      const valB = b[colName];
      if (typeof valA === 'number' && typeof valB === 'number') {
        return (valA - valB) * ascDesc;
      }
      return String(valA).localeCompare(String(valB)) * ascDesc;
    });
  }

  // Apply limits
  if (limitCount) {
    const lim = parseInt(limitCount, 10);
    targetCollection = targetCollection.slice(0, lim);
  }

  if (targetCollection.length === 0) {
    return { columns: fieldsSelected === '*' ? (tableName.toLowerCase() === 'users' ? ['user_id', 'username'] : ['score_id', 'score']) : [fieldsSelected], rows: [] };
  }

  // Map requested column keys
  const allColumns = Object.keys(targetCollection[0]);
  let finalColumns = allColumns;

  if (fieldsSelected.trim() !== '*') {
    const reqCols = fieldsSelected.split(',').map(s => s.trim().toLowerCase());
    finalColumns = allColumns.filter(c => reqCols.includes(c.toLowerCase()));
  }

  const finalRows = targetCollection.map(item => {
    const r: any = {};
    finalColumns.forEach(col => {
      r[col] = item[col];
    });
    return r;
  });

  return { columns: finalColumns, rows: finalRows };
}

export function recordPunishmentInMockDB(
  user_id: number,
  username: string,
  punishment_type: string,
  challenge_desc: string
): number {
  const state = getDatabaseState();
  if (!state.punishments) {
    state.punishments = [];
  }
  const nextId = state.punishments.reduce((max, p) => Math.max(max, p.punishment_id), 0) + 1;
  const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ');

  const newRecord = {
    punishment_id: nextId,
    user_id,
    username,
    punishment_type,
    challenge_desc,
    status: 'PENDING' as const,
    created_at: nowStr
  };
  state.punishments.push(newRecord);
  saveDatabaseState(state);
  return nextId;
}

export function redeemPunishmentInMockDB(punishment_id: number): boolean {
  const state = getDatabaseState();
  if (!state.punishments) return false;
  const idx = state.punishments.findIndex(p => p.punishment_id === punishment_id);
  if (idx !== -1) {
    const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ');
    state.punishments[idx].status = 'REDEEMED';
    state.punishments[idx].redeemed_at = nowStr;
    saveDatabaseState(state);
    return true;
  }
  return false;
}

export function getPunishmentsLogFromMockDB() {
  const state = getDatabaseState();
  return state.punishments || [];
}
