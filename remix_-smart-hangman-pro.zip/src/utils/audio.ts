// src/utils/audio.ts
// Handles synthesized sound effect triggers in the web browser using the standard Web Audio API.

let audioCtx: AudioContext | null = null;
let globalVolume = 0.5;
let globalMuted = false;
let globalWaveType: OscillatorType | 'custom' = 'sine'; // Fallback / customization override

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function setAudioVolume(vol: number) {
  globalVolume = Math.max(0, Math.min(1, vol));
}

export function setAudioMuted(muted: boolean) {
  globalMuted = muted;
}

export function setSynthWaveform(type: OscillatorType) {
  globalWaveType = type;
}

export function getAudioSettings() {
  return {
    volume: globalVolume,
    muted: globalMuted,
    waveType: globalWaveType
  };
}

export function playSynthSound(type: 'success' | 'fail' | 'win' | 'lose' | 'click' | 'hint') {
  if (globalMuted || globalVolume <= 0) return;

  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Helper to determine wave type. If standard wave matches global override, we use it or fall back
    const getWave = (defaultType: OscillatorType): OscillatorType => {
      if (globalWaveType !== 'sine') {
        return globalWaveType as OscillatorType;
      }
      return defaultType;
    };

    if (type === 'click') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = getWave('sine');
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(100, now + 0.05);
      
      const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
      gain.gain.setValueAtTime(0.05 * globalVolume * volMultiplier, now);
      gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + 0.05);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);
    } 
    else if (type === 'success') {
      // Prompt double rising beep
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = getWave('triangle');
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.setValueAtTime(1200, now + 0.08);
      
      const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
      gain.gain.setValueAtTime(0.1 * globalVolume * volMultiplier, now);
      gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + 0.2);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    }
    else if (type === 'fail') {
      // Disappointing low buzz sound
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = getWave('sawtooth');
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.linearRampToValueAtTime(120, now + 0.25);
      
      const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
      gain.gain.setValueAtTime(0.12 * globalVolume * volMultiplier, now);
      gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + 0.25);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    }
    else if (type === 'hint') {
      // Magical high pitch sparkle sound
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = getWave('sine');
      osc.frequency.setValueAtTime(1000, now);
      osc.frequency.exponentialRampToValueAtTime(2500, now + 0.15);
      
      const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
      gain.gain.setValueAtTime(0.08 * globalVolume * volMultiplier, now);
      gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + 0.2);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    }
    else if (type === 'win') {
      // Victory fanfare
      const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = getWave('triangle');
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);
        
        const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
        gain.gain.setValueAtTime(0.08 * globalVolume * volMultiplier, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + idx * 0.1 + 0.18);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.2);
      });
    }
    else if (type === 'lose') {
      // Melancholy descending chime
      const notes = [392.00, 311.13, 246.94, 196.00]; // G4, Eb4, B3, G3
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = getWave('sawtooth');
        osc.frequency.setValueAtTime(freq, now + idx * 0.15);
        
        const volMultiplier = osc.type === 'square' || osc.type === 'sawtooth' ? 0.3 : 1.0;
        gain.gain.setValueAtTime(0.08 * globalVolume * volMultiplier, now + idx * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.01 * globalVolume * volMultiplier, now + idx * 0.15 + 0.28);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.15);
        osc.stop(now + idx * 0.15 + 0.3);
      });
    }
  } catch (e) {
    console.warn("Web audio playback not permitted or unsupported: ", e);
  }
}
