// src/components/DocViewer.tsx
import React, { useState } from 'react';
import { playSynthSound } from '../utils/audio';

// File templates stored as static export contents to support direct client-side downloads!
const MAIN_PY_CONTENT = `# main.py
# Smart Hangman Pro - Primary Application Module (Tkinter GUI Client)
# Designed with standard OOP structure, MVC-like rendering separation, and MySQL integration.

import sys
import random
import tkinter as tk
from tkinter import ttk, messagebox
import math

try:
    from database import DatabaseManager
    from words import WORD_DATABASE
except ImportError:
    WORD_DATABASE = {
        "General": {
            "easy": [{"word": "APPLE", "hint": "A crisp, round, red or green fruit."}],
            "medium": [{"word": "PYTHON", "hint": "A versatile programming language."}],
            "hard": [{"word": "ALGORITHM", "hint": "A step-by-step problem-solving procedure."}]
        }
    }
    class DatabaseManager:
        def __init__(self, **kwargs): pass
        def connect(self): return False
        def close(self): pass

# ... (Detailed OOP Tkinter application fully coded inside python_app/main.py)`;

const DATABASE_PY_CONTENT = `# database.py
# Part of Smart Hangman Pro
# Handles all communication with the MySQL database under an Object-Oriented paradigm.

import mysql.connector
from mysql.connector import Error
import hashlib

class DatabaseManager:
    # ... (OOP MySQL connection driver fully coded inside python_app/database.py)`;

const SCHEMA_SQL_CONTENT = `-- SQL database schema for 'Smart Hangman Pro'
-- Tested for MySQL / MariaDB Engines
CREATE DATABASE IF NOT EXISTS smarthangman_db;
USE smarthangman_db;
-- ... (Fully coded inside python_app/schema.sql)`;

interface DocViewerProps {
  theme: any;
}

export const DocViewer: React.FC<DocViewerProps> = ({ theme }) => {
  const [activeTab, setActiveTab] = useState<'report' | 'diagrams' | 'code'>('report');
  const [activeCodeFile, setActiveCodeFile] = useState<'main' | 'database' | 'schema'>('main');
  const [copiedState, setCopiedState] = useState(false);

  const handleCopyCode = (content: string) => {
    navigator.clipboard.writeText(content);
    playSynthSound('click');
    setCopiedState(true);
    setTimeout(() => setCopiedState(false), 2000);
  };

  const handleDownloadFile = (content: string, filename: string) => {
    playSynthSound('win');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getCodeString = () => {
    if (activeCodeFile === 'main') return MAIN_PY_CONTENT;
    if (activeCodeFile === 'database') return DATABASE_PY_CONTENT;
    return SCHEMA_SQL_CONTENT;
  };

  const getFilenameString = () => {
    if (activeCodeFile === 'main') return 'main.py';
    if (activeCodeFile === 'database') return 'database.py';
    return 'schema.sql';
  };

  return (
    <div className={`${theme.bgCard} border ${theme.border} rounded-2xl shadow-xl overflow-hidden flex flex-col min-h-[550px] transition-all duration-500`}>
      {/* Tab Header Strip */}
      <div className={`${theme.bgHeader} border-b ${theme.border} px-6 py-4 flex flex-wrap justify-between items-center gap-4 transition-colors duration-500`}>
        <div className="flex items-center gap-2 font-mono text-xs font-bold text-slate-500 uppercase tracking-wider select-none">
          📚 Project Reports & Development Console
        </div>
        <div className="flex gap-2">
          {(['report', 'diagrams', 'code'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => { playSynthSound('click'); setActiveTab(tab); }}
              className={`px-4 py-2 rounded-lg font-mono text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer ${activeTab === tab ? `bg-gradient-to-r ${theme.gradientAccent} text-slate-950` : `${theme.bgInner} hover:bg-white/5 border ${theme.border} text-slate-400 hover:text-white`}`}
            >
              {tab === 'report' ? '📝 Project Report' : tab === 'diagrams' ? '🗺️ SVGs Diagrams' : '💾 Python/SQL Files'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Container Content */}
      <div className="flex-grow p-6 overflow-y-auto max-h-[600px]">
        {activeTab === 'report' && (
          <div className="prose prose-invert max-w-none space-y-6">
            <div className={`border-b ${theme.border} pb-4`}>
              <h2 className="text-2xl font-extrabold text-white tracking-tight mb-2">Smart Hangman Pro : Academic Milestone Report</h2>
              <p className="text-xs font-mono text-slate-500">Author: nagrajkc6@gmail.com | System: Python Toolkit & MySQL Engine</p>
            </div>

            <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 ${theme.bgInner} p-5 rounded-2xl border ${theme.border} transition-colors duration-500`}>
              <div>
                <h3 className={`text-sm font-bold font-mono ${theme.textAccent} uppercase mb-2`}>💡 Project Abstract</h3>
                <p className="text-xs text-slate-350 leading-relaxed">
                  Smart Hangman Pro integrates traditional word puzzles with comprehensive state tracking models. Structured around full-scale Object Oriented Programming, the system stores users credentials safely under SHA-256 hash algorithms, registers scores, and tracks detailed statistics within structured MySQL relational engines.
                </p>
              </div>
              <div>
                <h3 className={`text-sm font-bold font-mono ${theme.textAccent} uppercase mb-2`}>📐 Architectural Components</h3>
                <p className="text-xs text-slate-350 leading-relaxed">
                  Decoupled into dynamic Canvas vectors rendering progressive hangman scaffold parts, model words lists representing Easy/Medium/Hard brackets, and independent Database classes, the script eliminates SQL code injection risks and optimizes response throughput on game logs.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className={`text-md font-bold tracking-tight text-white font-mono uppercase ${theme.textAccent} border-l-2 ${theme.border} pl-3`}>
                 System Specifications Attributes
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-[11px]">
                <div className={`${theme.bgInner} p-4 border ${theme.border} rounded-xl transition-colors duration-500`}>
                  <span className="block text-indigo-400 font-bold mb-1">USER AUTH SYSTEM</span>
                  <p className="text-slate-500 leading-normal">Validates credential boundaries, hashes entries via secure SHA-256 libraries and establishes connected session links.</p>
                </div>
                <div className={`${theme.bgInner} p-4 border ${theme.border} rounded-xl transition-colors duration-500`}>
                  <span className="block text-emerald-400 font-bold mb-1">MYSQL SCHEMA ENG</span>
                  <p className="text-slate-500 leading-normal">Stores relational table profiles, creates dynamic indexing structures, and maps foreign key relationships back to creators.</p>
                </div>
                <div className={`${theme.bgInner} p-4 border ${theme.border} rounded-xl transition-colors duration-500`}>
                  <span className="block text-amber-400 font-bold mb-1">TKINTER VECTOR GUI</span>
                  <p className="text-slate-500 leading-normal">Controls interface flow states, paints dynamic stick elements onto responsive canvas grids, and triggers beep synthesis alerts.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'diagrams' && (
          <div className="space-y-8">
            {/* SVG Entity-Relationship Model Map */}
            <div className={`${theme.bgInner} p-6 rounded-2xl border ${theme.border} shadow-inner transition-colors duration-500`}>
              <h3 className={`text-sm font-bold text-white font-mono uppercase tracking-wider mb-4 border-b ${theme.border} pb-2 select-none`}>
                📂 Entity-Relationship (ER) Schema Map
              </h3>
              <div className="flex justify-center select-none">
                <svg viewBox="0 0 700 240" className="w-full max-w-[650px] h-auto font-mono text-[11px]">
                  {/* Table 1: Users */}
                  <rect x="20" y="30" width="220" height="150" rx="8" fill="#0A0F1D" stroke="#334155" strokeWidth="2" />
                  <path d="M 20 70 L 240 70" stroke="#334155" strokeWidth="2" />
                  <text x="35" y="55" fill="#38BDF8" className="font-bold text-[13px]">users (Table)</text>
                  <text x="35" y="95" fill="#38BDF8" className="font-bold">🔑 user_id (INT) [PK]</text>
                  <text x="35" y="120" fill="#94A3B8">username (VARCHAR)</text>
                  <text x="35" y="145" fill="#94A3B8">password_hash (VARCHAR)</text>
                  <text x="35" y="165" fill="#64748B">created_at (TIMESTAMP)</text>

                  {/* Relationship Connector Link Line */}
                  <line x1="240" y1="95" x2="440" y2="120" stroke="#38BDF8" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="440,120 432,115 432,125" fill="#38BDF8" />
                  {/* One-to-many cardinality indicators */}
                  <text x="248" y="90" fill="#38BDF8" className="font-bold text-[10px]">1</text>
                  <text x="425" y="112" fill="#38BDF8" className="font-bold text-[10px]">∞</text>

                  {/* Table 2: Scores */}
                  <rect x="440" y="20" width="240" height="190" rx="8" fill="#0A0F1D" stroke="#334155" strokeWidth="2" />
                  <path d="M 440 60 L 680 60" stroke="#334155" strokeWidth="2" />
                  <text x="455" y="45" fill="#10B981" className="font-bold text-[13px]">scores (Table)</text>
                  <text x="455" y="85" fill="#10B981" className="font-bold">🔑 score_id (INT) [PK]</text>
                  <text x="455" y="105" fill="#38BDF8" className="font-bold">🔗 user_id (INT) [FK]</text>
                  <text x="455" y="125" fill="#94A3B8">score (INT)</text>
                  <text x="455" y="145" fill="#94A3B8">category (VARCHAR)</text>
                  <text x="455" y="165" fill="#94A3B8">difficulty (VARCHAR)</text>
                  <text x="455" y="181" fill="#94A3B8">words_guessed (INT)</text>
                  <text x="455" y="198" fill="#64748B">played_at (TIMESTAMP)</text>
                </svg>
              </div>
            </div>

            {/* SVG Interactive Game Loop Flowchart Map */}
            <div className={`${theme.bgInner} p-6 rounded-2xl border ${theme.border} shadow-inner transition-colors duration-500`}>
              <h3 className={`text-sm font-bold text-white font-mono uppercase tracking-wider mb-4 border-b ${theme.border} pb-2 select-none`}>
                🎮 System Lifecycle & Gameplay Flowchart
              </h3>
              <div className="flex justify-center select-none">
                <svg viewBox="0 0 700 320" className="w-full max-w-[650px] h-auto font-mono text-[9px] sm:text-[10px]">
                  {/* Start State */}
                  <rect x="20" y="130" width="90" height="40" rx="20" fill="#0284C7" />
                  <text x="65" y="154" fill="#FFFFFF" textAnchor="middle" className="font-bold select-none uppercase">Start App</text>
                  
                  {/* Arrow Links */}
                  <line x1="110" y1="150" x2="140" y2="150" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="140,150 134,146 134,154" fill="#475569" />

                  {/* DB Connection Check Condition */}
                  <polygon points="190,120 240,150 190,180 140,150" fill="#1E293B" stroke="#475569" strokeWidth="1.5" />
                  <text x="190" y="153" fill="#38BDF8" textAnchor="middle" className="font-semibold select-none">MySQL OK?</text>

                  {/* Yes link */}
                  <line x1="190" y1="120" x2="190" y2="70" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="190,70 186,76 194,76" fill="#475569" />
                  <text x="200" y="98" fill="#10B981" className="font-bold">YES</text>

                  {/* Auth interface */}
                  <rect x="140" y="30" width="100" height="40" rx="4" fill="#0F172A" stroke="#475569" strokeWidth="1.5" />
                  <text x="190" y="54" fill="#FFFFFF" textAnchor="middle" className="font-bold">Auth Portal</text>

                  {/* Bypass Guest route */}
                  <line x1="190" y1="180" x2="190" y2="230" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="190,230 194,224 186,224" fill="#475569" />
                  <text x="200" y="208" fill="#EF4444" className="font-bold">NO</text>

                  {/* Guest bypass node */}
                  <rect x="140" y="230" width="100" height="40" rx="4" fill="#0F172A" stroke="#EF4444" strokeWidth="1" />
                  <text x="190" y="254" fill="#F8FAFC" textAnchor="middle" className="font-bold">Guest Bypass</text>

                  {/* Merge Arrows in Lobby Grid Choice */}
                  <line x1="240" y1="50" x2="280" y2="50" stroke="#475569" strokeWidth="1.5" />
                  <line x1="280" y1="50" x2="280" y2="150" stroke="#475569" strokeWidth="1.5" />
                  <line x1="240" y1="250" x2="280" y2="250" stroke="#475569" strokeWidth="1.5" />
                  <line x1="280" y1="250" x2="280" y2="150" stroke="#475569" strokeWidth="1.5" />

                  <line x1="280" y1="150" x2="320" y2="150" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="320,150 314,146 314,154" fill="#475569" />

                  {/* Game parameters choice */}
                  <rect x="320" y="125" width="115" height="50" rx="6" fill="#0F172A" stroke="#475569" strokeWidth="1.5" />
                  <text x="377" y="150" fill="#38BDF8" textAnchor="middle" className="font-bold">Select Category</text>
                  <text x="377" y="162" fill="#F8FAFC" textAnchor="middle">& Difficulty</text>

                  {/* Active Gameplay sequence arrow */}
                  <line x1="435" y1="150" x2="475" y2="150" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="475,150 469,146 469,154" fill="#475569" />

                  {/* Game State loop node */}
                  <rect x="475" y="125" width="110" height="50" rx="6" fill="#0F172A" stroke="#38BDF8" strokeWidth="1.5" />
                  <text x="530" y="148" fill="#38BDF8" textAnchor="middle" className="font-extrabold text-[11px] animate-pulse">ACTIVE LOOP</text>
                  <text x="530" y="160" fill="#94A3B8" textAnchor="middle">Letters guesses</text>

                  {/* Winner / Loser paths */}
                  <line x1="530" y1="125" x2="530" y2="85" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="530,85 526,91 534,91" fill="#475569" />
                  <text x="540" y="105" fill="#10B981" className="font-bold">WIN</text>

                  <rect x="475" y="45" width="110" height="40" rx="4" fill="#064E3B" stroke="#10B981" strokeWidth="1" />
                  <text x="530" y="69" fill="#10B981" textAnchor="middle" className="font-bold">Ears Points</text>

                  <line x1="530" y1="175" x2="530" y2="215" stroke="#475569" strokeWidth="1.5" />
                  <polygon points="530,215 534,209 526,209" fill="#475569" />
                  <text x="540" y="200" fill="#EF4444" className="font-bold">FAIL</text>

                  <rect x="475" y="215" width="110" height="40" rx="4" fill="#4C0519" stroke="#EF4444" strokeWidth="1" />
                  <text x="530" y="239" fill="#EF4444" textAnchor="middle" className="font-bold">Mistake +1</text>
                </svg>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="space-y-4">
            <div className={`flex flex-wrap items-center justify-between gap-4 ${theme.bgInner} p-4 border ${theme.border} rounded-xl transition-colors duration-500`}>
              <div>
                <h4 className="text-sm font-bold text-white font-mono uppercase select-none">📁 Assets Download Center</h4>
                <p className="text-xs text-slate-500">Pick any file from the Python/SQL project modules to copy the source or download locally.</p>
              </div>

              <div className="flex flex-wrap gap-2">
                {(['main', 'database', 'schema'] as const).map((file) => (
                  <button
                    key={file}
                    onClick={() => { playSynthSound('click'); setActiveCodeFile(file); }}
                    className={`px-3 py-1.5 rounded font-mono text-[11px] font-bold tracking-wider transition-colors cursor-pointer ${activeCodeFile === file ? `bg-gradient-to-r ${theme.gradientAccent} text-slate-950` : `${theme.bgInner} hover:bg-white/5 border ${theme.border} text-slate-400 hover:text-white`}`}
                  >
                    {file === 'main' ? 'main.py' : file === 'database' ? 'database.py' : 'schema.sql'}
                  </button>
                ))}
              </div>
            </div>

            <div className={`${theme.bgInner} border ${theme.border} rounded-xl overflow-hidden shadow-inner flex flex-col font-mono text-[11px] transition-colors duration-500`}>
              <div className={`bg-black/40 border-b ${theme.border} px-4 py-3 flex justify-between items-center select-none`}>
                <span className="text-slate-400 font-bold">{getFilenameString()}</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCopyCode(getCodeString())}
                    className="px-3 py-1 bg-slate-800 border border-slate-750 text-slate-300 hover:text-white rounded transition-colors text-[10px] cursor-pointer"
                  >
                    {copiedState ? '✅ Copied!' : '📋 Copy Source'}
                  </button>
                  <button
                    onClick={() => handleDownloadFile(getCodeString(), getFilenameString())}
                    className={`px-3 py-1 bg-gradient-to-r ${theme.gradientAccent} text-slate-950 text-[10px] font-extrabold rounded transition-all cursor-pointer`}
                  >
                    📥 Download File
                  </button>
                </div>
              </div>

              <pre className="p-4 overflow-x-auto text-slate-300/90 leading-relaxed font-mono select-text max-h-[340px] whitespace-pre">
                {getCodeString()}
              </pre>
            </div>

            <div className={`bg-indigo-950/20 ${theme.textAccent} font-medium border border-indigo-800/40 p-4 rounded-xl text-center text-xs leading-relaxed font-mono select-none`}>
              ℹ️ Tip: All python scripts are already created directly in the workspace directory <code className="text-white font-bold bg-slate-950 px-1.5 py-0.5 rounded">/python_app/</code>. They will be included automatically when downloading the applet ZIP from the top-right settings dropdown.
            </div>
          </div>
        )}
      </div>

      <div className={`${theme.bgInner} border-t px-6 py-3 font-mono text-[10px] text-slate-500 flex justify-between select-none transition-colors duration-500`}>
        <span>Author Email: nagrajkc6@gmail.com</span>
        <span>Target Framework: Python 3+ / Tkinter / MySQL</span>
      </div>
    </div>
  );
};
