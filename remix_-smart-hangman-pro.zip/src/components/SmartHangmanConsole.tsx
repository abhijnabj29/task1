// src/components/SmartHangmanConsole.tsx
import React, { useState, useEffect } from 'react';
import { Difficulty, WordItem } from '../types';
import { 
  recordScoreInMockDB, 
  getUserAnalyticsFromMockDB, 
  getGlobalLeaderboardFromMockDB,
  recordPunishmentInMockDB,
  redeemPunishmentInMockDB
} from '../utils/dbMock';
import { playSynthSound } from '../utils/audio';

const WORD_DATABASE: { [key: string]: { [key in Difficulty]: WordItem[] } } = {
  Technology: {
    easy: [
      { word: "MOUSE", hint: "A hand-held pointing device used for computers." },
      { word: "EMAIL", hint: "Electronic mail used to exchange messages over internet." },
      { word: "ROUTER", hint: "A device that forwards data packets between computer networks." },
      { word: "SCREEN", hint: "A flat surface on which pictures or words are shown on a monitor." }
    ],
    medium: [
      { word: "DATABASE", hint: "An organized collection of structured information or data." },
      { word: "PYTHON", hint: "A versatile high-level OOP programming language." },
      { word: "FIREWALL", hint: "A network security system that monitors and controls incoming traffic." },
      { word: "INTERNET", hint: "A global computer network providing a variety of information." }
    ],
    hard: [
      { word: "ALGORITHM", hint: "A process or set of rules to be followed in calculations or problem-solving." },
      { word: "KUBERNETES", hint: "An open-source container orchestration system for automating application deployment." },
      { word: "CRYPTOGRAPHY", hint: "The practice and study of techniques for secure communication." },
      { word: "CYBERSECURITY", hint: "The practice of protecting systems, networks, and programs from digital attacks." }
    ]
  },
  Sports: {
    easy: [
      { word: "SOCCER", hint: "A game played by two teams of eleven players with a round ball." },
      { word: "TENNIS", hint: "A racket sport played individually against a single opponent or between two teams of two." },
      { word: "GOLF", hint: "A club-and-ball sport played on a course with 9 or 18 holes." },
      { word: "CHESS", hint: "A two-player strategy board game played on a checkered board." }
    ],
    medium: [
      { word: "BASEBALL", hint: "A bat-and-ball game played between two opposing teams who take turns batting and fielding." },
      { word: "CRICKET", hint: "A bat-and-ball game played on a field with a 22-yard pitch in the center." },
      { word: "ATHLETE", hint: "A person who is proficient in sports and other forms of physical exercise." },
      { word: "MARATHON", hint: "A long-distance running race with an official distance of 42.195 kilometers." }
    ],
    hard: [
      { word: "GYMNASTICS", hint: "Exercises developing or displaying physical agility and coordination." },
      { word: "BADMINTON", hint: "A racket sport played using shuttlecocks across a net." },
      { word: "VELODROME", hint: "An arena for track cycling, featuring steep banked oval tracks." },
      { word: "DECATHLON", hint: "An athletic event taking place over two days, in which contestants compete in ten track and field events." }
    ]
  },
  Movies: {
    easy: [
      { word: "AVATAR", hint: "A high-grossing sci-fi film set on the lush moon of Pandora." },
      { word: "TITANIC", hint: "A romantic disaster movie of an unsinkable ship." },
      { word: "BATMAN", hint: "A wealthy American playboy who fights crime in Gotham City." },
      { word: "FROZEN", hint: "An animated musical fantasy film featuring Elsa and Anna." }
    ],
    medium: [
      { word: "INCEPTION", hint: "A mental heist thriller where thieves enter people's dreams." },
      { word: "GLADIATOR", hint: "An epic historical drama following Maximus Decimus Meridius." },
      { word: "AVENGERS", hint: "A team of extraordinary superheroes assemble to save Earth." },
      { word: "WHIPLASH", hint: "A music student's struggle under an abusive jazz instructor." }
    ],
    hard: [
      { word: "INTERSTELLAR", hint: "An epic sci-fi space odyssey involving black holes and wormholes." },
      { word: "CASABLANCA", hint: "A classic romantic drama set during World War II in Morocco." },
      { word: "PULPFICTION", hint: "A Neo-noir crime film directed by Quentin Tarantino." },
      { word: "SCHINDLERSLIST", hint: "An epic historical drama based on the life of an industrialist during WWII." }
    ]
  },
  Animals: {
    easy: [
      { word: "LION", hint: "The king of the jungle." },
      { word: "ZEBRA", hint: "An African wild horse with black-and-white stripes." },
      { word: "DOLPHIN", hint: "A highly intelligent marine mammal known for its playful behavior." },
      { word: "RABBIT", hint: "A small mammal with long ears, long hind legs, and a short fluffy tail." }
    ],
    medium: [
      { word: "KANGAROO", hint: "A large jumping marsupial from Australia." },
      { word: "PENGUIN", hint: "A flightless aquatic bird living almost exclusively in the Southern Hemisphere." },
      { word: "CHIMPANZEE", hint: "Great apes native to the forests of tropical Africa, sharing 98% human DNA." },
      { word: "OCTOPUS", hint: "A soft-bodied, eight-limbed mollusk." }
    ],
    hard: [
      { word: "CAMELOPARD", hint: "The archaic historical name for a giraffe." },
      { word: "CHAMELEON", hint: "A highly specialized lizard famous for its color-changing ability." },
      { word: "PLATYPUS", hint: "A semiaquatic egg-laying mammal endemic to eastern Australia." },
      { word: "AXOLOTL", hint: "An aquatic salamander known for its capacity to regenerate limbs." }
    ]
  }
};

interface SmartHangmanConsoleProps {
  currentUser: { user_id: number; username: string };
  onScoresUpdated: () => void;
}

export const SmartHangmanConsole: React.FC<SmartHangmanConsoleProps> = ({ currentUser, onScoresUpdated }) => {
  // Game Setup States
  const [inGame, setInGame] = useState(false);
  const [category, setCategory] = useState("Technology");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [showDocs, setShowDocs] = useState(false);

  // Active word States
  const [currentWordItem, setCurrentWordItem] = useState<WordItem | null>(null);
  const [guessedLetters, setGuessedLetters] = useState<Set<string>>(new Set());
  const [mistakesMade, setMistakesMade] = useState(0);
  const [score, setScore] = useState(0);
  const [streakCount, setStreakCount] = useState(0);
  const [hintUsed, setHintUsed] = useState(false);
  const [showHintMsg, setShowHintMsg] = useState(false);
  
  // End of game flags
  const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');

  // Stats / Dashboard
  const [analytics, setAnalytics] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);

  // Real Punishment state machine
  const [activePunishment, setActivePunishment] = useState<{
    punishment_id: number;
    punishment_type: 'apology' | 'math';
    challenge_desc: string;
    target_apology?: string;
    math_q1?: string;
    math_a1?: number;
    math_q2?: string;
    math_a2?: number;
    math_q3?: string;
    math_a3?: number;
  } | null>(null);

  const [apologyInput, setApologyInput] = useState('');
  const [mathInput1, setMathInput1] = useState('');
  const [mathInput2, setMathInput2] = useState('');
  const [mathInput3, setMathInput3] = useState('');
  const [punishmentStatusMsg, setPunishmentStatusMsg] = useState('');

  useEffect(() => {
    refreshStatsData();
  }, [currentUser, inGame]);

  const refreshStatsData = () => {
    setAnalytics(getUserAnalyticsFromMockDB(currentUser.user_id));
    setLeaderboard(getGlobalLeaderboardFromMockDB(7));
  };

  const startNewPlay = () => {
    playSynthSound('click');
    const list = WORD_DATABASE[category][difficulty];
    const chosen = list[Math.floor(Math.random() * list.length)];
    setCurrentWordItem(chosen);
    setGuessedLetters(new Set());
    setMistakesMade(0);
    setHintUsed(false);
    setShowHintMsg(false);
    setGameState('playing');
    setInGame(true);
  };

  const triggerGallowsPunishment = () => {
    const runType = Math.random() > 0.5 ? 'apology' : 'math';
    
    if (runType === 'apology') {
      const apologies = [
        "I admit my spelling is a total disaster, spare the gallows!",
        "My computer master is smarter than me, I pledge to study more!",
        "The gallows has judged my vocabulary and found it deeply lacking.",
        "I apologize to this application for destroying six virtual lives."
      ];
      const selectedApology = apologies[Math.floor(Math.random() * apologies.length)];
      
      const punId = recordPunishmentInMockDB(
        currentUser.user_id,
        currentUser.username,
        'apology',
        `Apologize: "${selectedApology}"`
      );
      
      setActivePunishment({
        punishment_id: punId,
        punishment_type: 'apology',
        challenge_desc: `Must write the shame apology statement exactly to unlock your console license.`,
        target_apology: selectedApology
      });
      setApologyInput('');
      setPunishmentStatusMsg('');
    } else {
      const v1 = Math.floor(Math.random() * 8) + 3;
      const v2 = Math.floor(Math.random() * 7) + 3;
      const r1 = v1 * v2;
      
      const v3 = Math.floor(Math.random() * 40) + 10;
      const v4 = Math.floor(Math.random() * 40) + 10;
      const r2 = v3 + v4;

      const v5 = Math.floor(Math.random() * 80) + 20;
      const v6 = Math.floor(Math.random() * 19) + 5;
      const r3 = v5 - v6;

      const desc = `Math quiz: ${v1} * ${v2}, ${v3} + ${v4}, ${v5} - ${v6}`;
      const punId = recordPunishmentInMockDB(
        currentUser.user_id,
        currentUser.username,
        'math',
        desc
      );

      setActivePunishment({
        punishment_id: punId,
        punishment_type: 'math',
        challenge_desc: `Complete 3 quantum CPU arithmetic decryptions to recharge the gallows circuit!`,
        math_q1: `${v1} \u00D7 ${v2}`,
        math_a1: r1,
        math_q2: `${v3} + ${v4}`,
        math_a2: r2,
        math_q3: `${v5} - ${v6}`,
        math_a3: r3
      });
      setMathInput1('');
      setMathInput2('');
      setMathInput3('');
      setPunishmentStatusMsg('');
    }
  };

  const handleSubmitPunishment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePunishment) return;

    if (activePunishment.punishment_type === 'apology') {
      if (apologyInput.trim() === activePunishment.target_apology) {
        redeemPunishmentInMockDB(activePunishment.punishment_id);
        playSynthSound('success');
        setPunishmentStatusMsg("✅ APOLOGY ACCEPTED! Gallows retracted.");
        setTimeout(() => {
          setActivePunishment(null);
          onScoresUpdated();
        }, 1500);
      } else {
        playSynthSound('fail');
        setPunishmentStatusMsg("❌ Incorrect Statement! Mind your commas, periods, and spacing exactly!");
      }
    } else {
      const a1 = parseInt(mathInput1, 10);
      const a2 = parseInt(mathInput2, 10);
      const a3 = parseInt(mathInput3, 10);

      if (
        a1 === activePunishment.math_a1 &&
        a2 === activePunishment.math_a2 &&
        a3 === activePunishment.math_a3
      ) {
        redeemPunishmentInMockDB(activePunishment.punishment_id);
        playSynthSound('success');
        setPunishmentStatusMsg("✅ QUANTUM CIRCUITS RE-POWERED! System unlocked.");
        setTimeout(() => {
          setActivePunishment(null);
          onScoresUpdated();
        }, 1500);
      } else {
        playSynthSound('fail');
        setPunishmentStatusMsg("❌ Decryption sums invalid! Mainframe core remaining locked!");
      }
    }
  };

  const handleGuess = (letter: string) => {
    if (gameState !== 'playing' || guessedLetters.has(letter)) return;
    
    playSynthSound('click');
    const updated = new Set(guessedLetters);
    updated.add(letter);
    setGuessedLetters(updated);

    const isCorrect = currentWordItem?.word.toUpperCase().includes(letter);
    if (isCorrect) {
      playSynthSound('success');
      // Assess if complete word guessed
      const isWordComplete = currentWordItem?.word
        .toUpperCase()
        .split('')
        .every((ch) => updated.has(ch));
      
      if (isWordComplete) {
        setGameState('won');
        playSynthSound('win');
        
        // Calculations
        const basePoints = difficulty === 'easy' ? 100 : difficulty === 'medium' ? 200 : 400;
        const penaltyMultiplier = hintUsed ? 0.5 : 1.0;
        const pts = Math.round(basePoints * penaltyMultiplier);
        
        setScore(prev => prev + pts);
        setStreakCount(prev => prev + 1);
      }
    } else {
      playSynthSound('fail');
      const newMistakes = mistakesMade + 1;
      setMistakesMade(newMistakes);
      
      if (newMistakes >= 6) {
        setGameState('lost');
        playSynthSound('lose');
        setStreakCount(0);
        triggerGallowsPunishment();
      }
    }
  };

  const activateHint = () => {
    if (hintUsed) return;
    playSynthSound('hint');
    setHintUsed(true);
    setShowHintMsg(true);
  };

  const loadNextInStreak = () => {
    playSynthSound('click');
    const list = WORD_DATABASE[category][difficulty];
    let chosen = list[Math.floor(Math.random() * list.length)];
    while (chosen.word.toUpperCase() === currentWordItem?.word.toUpperCase() && list.length > 1) {
      chosen = list[Math.floor(Math.random() * list.length)];
    }
    setCurrentWordItem(chosen);
    setGuessedLetters(new Set());
    setMistakesMade(0);
    setHintUsed(false);
    setShowHintMsg(false);
    setGameState('playing');
  };

  const gameOverExit = () => {
    playSynthSound('click');
    // Save results to Database
    if (score > 0) {
      recordScoreInMockDB(
        currentUser.user_id,
        score,
        category,
        difficulty,
        streakCount
      );
      onScoresUpdated();
    }
    setScore(0);
    setStreakCount(0);
    setInGame(false);
  };

  // Modern Vector Drawing Platform mapping mistakes progresion
  const renderHangmanSVG = () => {
    return (
      <svg viewBox="0 0 200 250" className="w-full max-w-[200px] xl:max-w-[240px] h-auto drop-shadow-lg mx-auto">
        {/* Gallows wood structures */}
        <line x1="20" y1="230" x2="180" y2="230" stroke="#475569" strokeWidth="6" strokeLinecap="round" />
        <line x1="60" y1="230" x2="60" y2="20" stroke="#475569" strokeWidth="8" strokeLinecap="round" />
        <line x1="60" y1="20" x2="140" y2="20" stroke="#475569" strokeWidth="8" strokeLinecap="round" />
        <line x1="60" y1="60" x2="100" y2="20" stroke="#475569" strokeWidth="4" />
        <line x1="140" y1="20" x2="140" y2="55" stroke="#D97706" strokeWidth="3" />

        {/* Head */}
        {mistakesMade >= 1 && (
          <circle cx="140" cy="72" r="16" stroke="#38BDF8" strokeWidth="4" fill="none" className="transition-all duration-300" />
        )}
        
        {/* Body Spine */}
        {mistakesMade >= 2 && (
          <line x1="140" y1="88" x2="140" y2="150" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" className="transition-all duration-300" />
        )}
        
        {/* Left Arm */}
        {mistakesMade >= 3 && (
          <line x1="140" y1="105" x2="110" y2="125" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" className="transition-all duration-300" />
        )}
        
        {/* Right Arm */}
        {mistakesMade >= 4 && (
          <line x1="140" y1="105" x2="170" y2="125" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" className="transition-all duration-300" />
        )}
        
        {/* Left Leg */}
        {mistakesMade >= 5 && (
          <line x1="140" y1="150" x2="115" y2="200" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" className="transition-all duration-300" />
        )}
        
        {/* Right Leg */}
        {mistakesMade >= 6 && (
          <line x1="140" y1="150" x2="165" y2="200" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" className="transition-all duration-300" />
        )}
      </svg>
    );
  };

  const getWordMask = () => {
    if (!currentWordItem) return "";
    return currentWordItem.word
      .toUpperCase()
      .split('')
      .map((ch) => (guessedLetters.has(ch) ? ch : '_'))
      .join(' ');
  };

  return (
    <div className="w-full">
      {!inGame ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT GRID: Game Setup Options */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 lg:p-8 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-28 h-28 bg-cyan-500/5 rounded-full blur-3xl -z-10" />
            <h3 className="text-xl font-bold tracking-tight text-white mb-1">
              GAME SETUP ENGINE
            </h3>
            <p className="text-sm text-slate-400 mb-6">Configure difficulty matrix parameters:</p>

            <div className="space-y-6">
              {/* Category selection */}
              <div>
                <label className="block text-slate-300 font-semibold text-sm mb-2">Category</label>
                <div className="grid grid-cols-2 gap-3" id="category-selector-grid">
                  {Object.keys(WORD_DATABASE).map((catName) => (
                    <button
                      key={catName}
                      id={`btn-cat-${catName}`}
                      onClick={() => { playSynthSound('click'); setCategory(catName); }}
                      className={`py-3 px-4 rounded-xl border text-left font-medium transition-all cursor-pointer ${category === catName ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'}`}
                    >
                      <div className="text-xs font-mono text-slate-500 mb-0.5">Category</div>
                      <div className="text-sm font-semibold">{catName}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Difficulty selection */}
              <div>
                <label className="block text-slate-300 font-semibold text-sm mb-2">Difficulty</label>
                <div className="grid grid-cols-3 gap-3" id="difficulty-selector-grid">
                  {(['easy', 'medium', 'hard'] as Difficulty[]).map((level) => (
                    <button
                      key={level}
                      id={`btn-diff-${level}`}
                      onClick={() => { playSynthSound('click'); setDifficulty(level); }}
                      className={`py-2 px-3 rounded-lg border font-mono text-xs uppercase text-center font-bold tracking-wider transition-all cursor-pointer ${difficulty === level ? 'bg-cyan-500 text-slate-950 border-cyan-500 shadow-md' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'}`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={startNewPlay}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 font-extrabold text-base py-4 rounded-xl shadow-lg transition-transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
                id="btn-start-game"
              >
                🎮 INITIALIZE SMART GAMEBOARD
              </button>
            </div>
          </div>

          {/* RIGHT GRID: Dashboard, Rankings & Statistics */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Real Stats Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h3 className="text-md font-bold tracking-widest text-slate-400 uppercase font-mono mb-4">
                📈 CURRENT PLAYER METRICS
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800">
                  <span className="block text-slate-500 text-[10px] uppercase font-mono font-bold tracking-wider">TOTAL GAMES</span>
                  <span className="block text-xl font-bold text-cyan-400 mt-1">{analytics?.total_games ?? 0}</span>
                </div>
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800">
                  <span className="block text-slate-500 text-[10px] uppercase font-mono font-bold tracking-wider">ACCUMULATED SCORE</span>
                  <span className="block text-xl font-bold text-emerald-400 mt-1">{analytics?.total_score ?? 0}</span>
                </div>
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800">
                  <span className="block text-slate-500 text-[10px] uppercase font-mono font-bold tracking-wider">AVERAGE / GAME</span>
                  <span className="block text-xl font-bold text-amber-400 mt-1">{analytics?.avg_score ?? 0}</span>
                </div>
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800">
                  <span className="block text-slate-500 text-[10px] uppercase font-mono font-bold tracking-wider">WORDS GUESS</span>
                  <span className="block text-xl font-bold text-pink-400 mt-1">{analytics?.total_words_guessed ?? 0}</span>
                </div>
              </div>
            </div>

            {/* Local Leaderboard Display */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex-1">
              <h3 className="text-md font-bold tracking-widest text-slate-400 uppercase font-mono mb-3">
                🏆 SERVER LEADERBOARD
              </h3>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {leaderboard.map((record, index) => (
                  <div key={index} className="flex justify-between items-center bg-slate-950/80 hover:bg-slate-950 border border-slate-850 px-4 py-2.5 rounded-lg transition-colors">
                    <div className="flex items-center gap-3">
                      <span className={`text-xs font-mono font-bold ${index === 0 ? 'text-amber-400' : index === 1 ? 'text-slate-300' : index === 2 ? 'text-amber-600' : 'text-slate-500'}`}>
                        #{index + 1}
                      </span>
                      <span className="text-sm font-semibold text-white">{record.username}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-mono text-sm font-bold">{record.score}</span>
                      <span className="text-[10px] text-slate-600 font-mono block uppercase">{record.category}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ACTIVE IN GAME SCREEN BOARD */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 lg:p-8 shadow-xl relative" id="active-gameplay-interface">
          {/* Header statistics strip */}
          <div className="flex flex-wrap justify-between items-center gap-4 bg-slate-950 border border-slate-800 px-6 py-4 rounded-xl mb-6">
            <div>
              <span className="text-xs font-mono text-slate-500 uppercase tracking-widest block">CATEGORY DIRECTORY</span>
              <span className="text-sm font-bold text-white uppercase">{category} </span>
              <span className="inline-block px-2 py-0.5 ml-2 bg-indigo-950 text-indigo-400 border border-indigo-800 text-[10px] font-mono rounded uppercase">{difficulty}</span>
            </div>

            <div className="flex items-center gap-8">
              <div className="text-center">
                <span className="text-xs font-mono text-slate-500 block">LIVES</span>
                <span className={`text-md font-extrabold font-mono ${6 - mistakesMade <= 2 ? 'text-red-500 animate-pulse' : 'text-emerald-400'}`}>
                  {6 - mistakesMade} remaining
                </span>
              </div>
              <div className="text-center">
                <span className="text-xs font-mono text-slate-500 block">SERIES WIN</span>
                <span className="text-md font-extrabold text-cyan-400 font-mono">{streakCount}</span>
              </div>
              <div className="text-center">
                <span className="text-xs font-mono text-slate-500 block">ACCUMULATED SCORE</span>
                <span className="text-md font-extrabold text-emerald-400 font-mono">{score} pts</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* SVG GALLOWS CANVAS COL */}
            <div className="lg:col-span-5 bg-slate-950 rounded-xl p-6 border border-slate-850 flex items-center justify-center min-h-[220px]">
              {renderHangmanSVG()}
            </div>

            {/* KEYBOARD INPUT INTERACTION COL */}
            <div className="lg:col-span-7 flex flex-col justify-between">
              <div>
                {/* Word dashes display */}
                <div className="text-center py-6">
                  <div className="tracking-[0.25em] font-mono text-4xl lg:text-5xl font-extrabold text-cyan-400 select-none">
                    {getWordMask()}
                  </div>
                </div>

                {/* Hints output banner */}
                <div className="mb-6 flex flex-col items-center min-h-[48px]">
                  {showHintMsg ? (
                    <div className="text-slate-300 font-medium text-xs bg-cyan-950/40 border border-cyan-800/80 rounded-lg px-4 py-3 text-center w-full max-w-sm animate-fade-in font-mono">
                      🌟 Hint: <span className="text-cyan-400">{currentWordItem?.hint}</span>
                    </div>
                  ) : (
                    <button
                      onClick={activateHint}
                      className="text-xs font-mono text-indigo-400 hover:text-indigo-300 bg-indigo-950/30 hover:bg-slate-950 border border-indigo-900/60 hover:border-indigo-850 rounded-full px-5 py-2 transition-all cursor-pointer"
                      id="btn-get-hint"
                    >
                      💡 Use hint (Earns 50% points penalty)
                    </button>
                  )}
                </div>
              </div>

              {/* Virtual typing keyboard */}
              <div>
                <div className="flex flex-col gap-2 max-w-lg mx-auto" id="virtual-keyboard-layout">
                  {["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"].map((row, rIdx) => (
                    <div key={rIdx} className="flex justify-center gap-1.5">
                      {row.split('').map((char) => {
                        const isGuessed = guessedLetters.has(char);
                        const isCorrect = currentWordItem?.word.toUpperCase().includes(char);
                        
                        return (
                          <button
                            key={char}
                            disabled={isGuessed || gameState !== 'playing'}
                            onClick={() => handleGuess(char)}
                            className={`w-9 h-10 sm:w-11 sm:h-11 rounded-lg font-bold font-mono text-sm sm:text-base transition-all select-none cursor-pointer ${
                              isGuessed
                                ? isCorrect
                                  ? 'bg-emerald-500 text-slate-950 font-extrabold'
                                  : 'bg-slate-850 border border-slate-800 text-slate-700'
                                : 'bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            {char}
                          </button>
                        );
                      })}
                    </div>
                  ))}
                </div>

                {/* Bottom navigation controllers */}
                <div className="flex justify-between items-center mt-8 pt-6 border-t border-slate-850">
                  <button
                    onClick={gameOverExit}
                    className="px-5 py-2.5 bg-slate-950 border border-slate-800 hover:border-slate-750 hover:bg-slate-800 text-slate-300 text-sm font-semibold rounded-lg transition-colors cursor-pointer"
                    id="btn-game-quit"
                  >
                    🚪 ABANDON BOARD
                  </button>

                  {gameState === 'playing' ? (
                    <button
                      onClick={loadNextInStreak}
                      className="px-5 py-2.5 bg-slate-950 border border-slate-800 hover:border-slate-750 text-slate-400 text-sm font-semibold rounded-lg transition-colors cursor-pointer"
                      id="btn-skip-word"
                    >
                      Skip word ➡️
                    </button>
                  ) : (
                    <div className="flex gap-3">
                      {gameState === 'won' ? (
                        <button
                          onClick={loadNextInStreak}
                          className="px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-sm rounded-lg shadow-md hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                          id="btn-next-streak"
                        >
                          🎉 NEXT ROUND SCREEN ➡️
                        </button>
                      ) : (
                        <button
                          onClick={startNewPlay}
                          className="px-6 py-2.5 bg-cyan-500 text-slate-950 font-extrabold text-sm rounded-lg shadow-md hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                          id="btn-retry-play"
                        >
                          🔄 RESTART GAME GRID
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Modal Overlay prompts on victory or collapse */}
          {/* Modal Overlay prompts on victory or collapse with optional Punishment lock */}
          {gameState !== 'playing' && (
            <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 rounded-2xl z-20 overflow-y-auto">
              {activePunishment ? (
                <div className="bg-slate-900 border-2 border-red-900/80 rounded-xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative animate-fade-in text-center">
                  <div className="absolute top-2 right-2 px-2 py-0.5 bg-red-950 text-red-500 border border-red-900/50 text-[10px] font-mono rounded select-none animate-pulse">
                    PUNISHMENT ID: #{activePunishment.punishment_id}
                  </div>
                  
                  <div className="text-4xl mb-3 text-center">💀</div>
                  
                  <h4 className="text-xl font-bold tracking-tight text-red-400 text-center uppercase font-mono">
                    GALLOWS PENALTY LOCKOUT
                  </h4>
                  <p className="text-xs text-slate-400 font-mono text-center leading-relaxed mt-2 mb-6">
                    {activePunishment.challenge_desc}
                  </p>

                  <form onSubmit={handleSubmitPunishment} className="space-y-5 text-left">
                    {activePunishment.punishment_type === 'apology' ? (
                      <div className="space-y-3">
                        <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg font-mono text-xs">
                          <span className="text-slate-500 block mb-1">PROMPT STATEMENT (TYPE EXACTLY):</span>
                          <span className="text-white font-semibold italic">"{activePunishment.target_apology}"</span>
                        </div>
                        
                        <div>
                          <label className="block text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">Your apology input</label>
                          <textarea
                            rows={3}
                            value={apologyInput}
                            onChange={(e) => setApologyInput(e.target.value)}
                            placeholder="Type the apology here exactly (case-sensitive)..."
                            className="w-full bg-slate-950 border border-slate-800 focus:border-red-500 rounded-lg p-3 text-sm text-slate-200 outline-none font-mono tracking-wide"
                            required
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <span className="text-xs text-slate-500 block font-mono">SOLVE CORE ARITHMETIC DECRYPTION TO POWER DOWN GALLOWS:</span>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg text-center">
                            <span className="block text-xs font-mono font-bold text-slate-400 mb-2">{activePunishment.math_q1}</span>
                            <input
                              type="number"
                              required
                              value={mathInput1}
                              onChange={(e) => setMathInput1(e.target.value)}
                              placeholder="Ans"
                              className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded p-1.5 text-center text-sm font-mono font-bold text-white select-all"
                            />
                          </div>

                          <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg text-center">
                            <span className="block text-xs font-mono font-bold text-slate-400 mb-2">{activePunishment.math_q2}</span>
                            <input
                              type="number"
                              required
                              value={mathInput2}
                              onChange={(e) => setMathInput2(e.target.value)}
                              placeholder="Ans"
                              className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded p-1.5 text-center text-sm font-mono font-bold text-white select-all"
                            />
                          </div>

                          <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg text-center font-mono">
                            <span className="block text-xs font-mono font-bold text-slate-400 mb-2">{activePunishment.math_q3}</span>
                            <input
                              type="number"
                              required
                              value={mathInput3}
                              onChange={(e) => setMathInput3(e.target.value)}
                              placeholder="Ans"
                              className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded p-1.5 text-center text-sm font-mono font-bold text-white select-all"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {punishmentStatusMsg && (
                      <div className={`p-3 rounded-lg text-center font-semibold text-xs tracking-wide font-mono ${
                        punishmentStatusMsg.includes('✅') 
                          ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-950' 
                          : 'bg-red-950/40 text-red-400 border border-red-950'
                      }`}>
                        {punishmentStatusMsg}
                      </div>
                    )}

                    <div className="flex flex-col sm:flex-row gap-3 pt-2">
                      <button
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-red-600 to-amber-600 hover:brightness-110 text-white font-extrabold py-3 rounded-lg transition-all cursor-pointer font-mono text-xs uppercase tracking-widest"
                      >
                        ⚡ Submit Penance Decrypt
                      </button>
                      <button
                        type="button"
                        onClick={gameOverExit}
                        className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 font-mono text-xs py-3 px-4 rounded-lg transition-all cursor-pointer"
                      >
                        Abandon Session
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 max-w-sm w-full text-center shadow-2xl relative">
                  <div className={`text-4xl mb-4 ${gameState === 'won' ? 'animate-bounce' : 'animate-pulse'}`}>
                    {gameState === 'won' ? '🎉' : '💀'}
                  </div>
                  <h4 className="text-2xl font-bold tracking-tight text-white mb-2">
                    {gameState === 'won' ? 'WORD DECODED!' : 'PUNISHMENT FULFILLED!'}
                  </h4>
                  <p className="text-slate-450 font-mono text-sm leading-relaxed mb-6">
                    {gameState === 'won' 
                      ? `Excellent structural decryption! You correctly mapped "${currentWordItem?.word.toUpperCase()}"! Ready for next?`
                      : `Gallows penalty record cleared! The exact answer was "${currentWordItem?.word.toUpperCase()}". Your credentials are now reinstated and healthy.`}
                  </p>
                  <div className="flex flex-col gap-3">
                    {gameState === 'won' ? (
                      <button
                        onClick={loadNextInStreak}
                        className="w-full bg-cyan-500 text-slate-950 font-bold py-3 rounded-lg hover:brightness-110 transition-all cursor-pointer"
                        id="btn-modal-next"
                      >
                        CONTINUE SEQUENCE
                      </button>
                    ) : (
                      <button
                        onClick={startNewPlay}
                        className="w-full bg-cyan-500 text-slate-950 font-bold py-3 rounded-lg hover:brightness-110 transition-all cursor-pointer"
                        id="btn-modal-retry"
                      >
                        TRY NEW WORD
                      </button>
                    )}
                    <button
                      onClick={gameOverExit}
                      className="w-full bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-400 font-semibold py-2.5 rounded-lg transition-colors cursor-pointer text-xs"
                      id="btn-modal-exit"
                    >
                      Return to Lobby Console
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
