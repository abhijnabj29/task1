// src/components/DatabaseExplorer.tsx
import React, { useState, useEffect } from 'react';
import { interpretSQLMock, getDatabaseState } from '../utils/dbMock';
import { playSynthSound } from '../utils/audio';
import { AppTheme } from '../utils/themes';

interface DatabaseExplorerProps {
  scoreTrigger: number;
  theme: AppTheme;
}

export const DatabaseExplorer: React.FC<DatabaseExplorerProps> = ({ scoreTrigger, theme }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'scores' | 'punishments' | 'terminal'>('users');
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM users;');
  const [terminalResults, setTerminalResults] = useState<{ columns: string[]; rows: any[]; error?: string } | null>(null);
  
  // Direct Table Fetch lists
  const [userData, setUserData] = useState<any[]>([]);
  const [scoreData, setScoreData] = useState<any[]>([]);
  const [punishmentData, setPunishmentData] = useState<any[]>([]);

  useEffect(() => {
    fetchTables();
  }, [scoreTrigger, activeTab]);

  const fetchTables = () => {
    const state = getDatabaseState();
    setUserData(state.users);
    setScoreData(state.scores);
    setPunishmentData(state.punishments || []);
  };

  const handleExecuteSQL = (e: React.FormEvent) => {
    e.preventDefault();
    playSynthSound('click');
    const result = interpretSQLMock(sqlQuery);
    setTerminalResults(result);
    fetchTables(); // Sync table displays if anything changes (e.g. mock insert warnings)
  };

  const loadPreset = (preset: string) => {
    playSynthSound('click');
    setSqlQuery(preset);
    const result = interpretSQLMock(preset);
    setTerminalResults(result);
  };

  return (
    <div className={`${theme.bgCard} border rounded-2xl shadow-xl overflow-hidden flex flex-col min-h-[500px] transition-all duration-500`}>
      {/* Console top frame */}
      <div className={`${theme.bgInner} border-b px-6 py-4 flex flex-wrap justify-between items-center gap-4 transition-colors duration-500`}>
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500/85 block" />
            <span className="w-3 h-3 rounded-full bg-amber-500/85 block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/85 block" />
          </div>
          <span className="font-mono text-xs font-bold text-slate-500 uppercase tracking-wider">
            🐬 Visual MySQL Admin Workbench v8.0
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {(['users', 'scores', 'punishments', 'terminal'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => { playSynthSound('click'); setActiveTab(tab); }}
              className={`px-3 py-1.5 rounded-lg font-mono text-xs uppercase font-bold tracking-wider transition-all cursor-pointer ${activeTab === tab ? `${theme.bgAccent} ${theme.accentShadow}` : `bg-black/30 hover:bg-white/5 border ${theme.border} text-slate-400 hover:text-white`}`}
            >
              {tab === 'terminal' ? '💻 Query CLI' : tab === 'punishments' ? '💀 Punishment Logs' : `📁 Table: ${tab}`}
            </button>
          ))}
        </div>
      </div>

      {/* Main workspace panels */}
      <div className="flex-1 p-6 bg-slate-900/60 overflow-y-auto">
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-slate-950/60 p-4 border border-slate-850 rounded-xl">
              <div>
                <h4 className="text-sm font-bold text-white font-mono uppercase">smarthangman_db.users</h4>
                <p className="text-xs text-slate-500">Decrypts secure usernames and SHA256 hashed credentials stored on database server.</p>
              </div>
              <span className="px-2.5 py-1 bg-slate-850 text-slate-400 font-mono text-xs font-semibold rounded-full border border-slate-800">
                {userData.length} rows inside
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950 shadow-inner">
              <table className="w-full font-mono text-xs text-left text-slate-300">
                <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th scope="col" className="px-4 py-3">user_id</th>
                    <th scope="col" className="px-4 py-3">username</th>
                    <th scope="col" className="px-4 py-3">password_hash (SHA-256)</th>
                    <th scope="col" className="px-4 py-3">created_at</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {userData.map((row) => (
                    <tr key={row.user_id} className="hover:bg-slate-900/40">
                      <td className="px-4 py-3 text-cyan-400 font-bold">{row.user_id}</td>
                      <td className="px-4 py-3 text-indigo-200 font-semibold">{row.username}</td>
                      <td className="px-4 py-3 font-mono text-slate-500 break-all leading-relaxed whitespace-normal max-w-xs xl:max-w-md">
                        {row.password_hash}
                      </td>
                      <td className="px-4 py-3 text-slate-450 text-[10px]">{row.created_at}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'scores' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-slate-950/60 p-4 border border-slate-850 rounded-xl">
              <div>
                <h4 className="text-sm font-bold text-white font-mono uppercase">smarthangman_db.scores</h4>
                <p className="text-xs text-slate-500">Game logs registering point sums, words guessed counts, difficulty settings, and time records.</p>
              </div>
              <span className="px-2.5 py-1 bg-slate-850 text-slate-400 font-mono text-xs font-semibold rounded-full border border-slate-800">
                {scoreData.length} records logged
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950 shadow-inner">
              <table className="w-full font-mono text-xs text-left text-slate-300">
                <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th scope="col" className="px-4 py-3">score_id</th>
                    <th scope="col" className="px-4 py-3">user_id</th>
                    <th scope="col" className="px-4 py-3">score</th>
                    <th scope="col" className="px-4 py-3">category</th>
                    <th scope="col" className="px-4 py-3">difficulty</th>
                    <th scope="col" className="px-4 py-3">words_guessed</th>
                    <th scope="col" className="px-4 py-3">played_at</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {[...scoreData].reverse().map((row) => (
                    <tr key={row.score_id} className="hover:bg-slate-900/40">
                      <td className="px-4 py-3 text-slate-550">{row.score_id}</td>
                      <td className="px-4 py-3 text-cyan-400 font-bold">{row.user_id}</td>
                      <td className="px-4 py-3 text-emerald-400 font-bold text-sm">{row.score}</td>
                      <td className="px-4 py-3 text-slate-300">{row.category}</td>
                      <td className="px-4 py-3 text-indigo-400">{row.difficulty}</td>
                      <td className="px-4 py-3 text-pink-400">{row.words_guessed}</td>
                      <td className="px-4 py-3 text-slate-450 text-[10px]">{row.played_at}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'punishments' && (
          <div className="space-y-4 animate-fade-in animate-duration-100">
            <div className={`flex justify-between items-center ${theme.bgInner} p-4 border rounded-xl transition-colors duration-500`}>
              <div>
                <h4 className="text-sm font-bold text-white font-mono uppercase">smarthangman_db.punishments</h4>
                <p className="text-xs text-slate-500">Academic shame records tracking active/historical punishments for gallows failure states.</p>
              </div>
              <span className={`px-2.5 py-1 bg-red-950/40 text-red-400 font-mono text-xs font-semibold rounded-full border border-red-900`}>
                {punishmentData.length} records logged
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950 shadow-inner">
              <table className="w-full font-mono text-xs text-left text-slate-300">
                <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th scope="col" className="px-4 py-3">id</th>
                    <th scope="col" className="px-4 py-3">username</th>
                    <th scope="col" className="px-4 py-3">type</th>
                    <th scope="col" className="px-4 py-3">challenge_desc</th>
                    <th scope="col" className="px-4 py-3">status</th>
                    <th scope="col" className="px-4 py-3">created_at</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {[...punishmentData].reverse().map((row) => (
                    <tr key={row.punishment_id} className="hover:bg-slate-900/40">
                      <td className="px-4 py-3 text-slate-550">{row.punishment_id}</td>
                      <td className="px-4 py-3 text-cyan-400 font-bold">{row.username} (ID:{row.user_id})</td>
                      <td className="px-4 py-3 text-indigo-400 uppercase font-semibold">{row.punishment_type}</td>
                      <td className="px-4 py-3 text-slate-300 italic max-w-xs truncate" title={row.challenge_desc}>{row.challenge_desc}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${row.status === 'REDEEMED' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-900' : 'bg-red-950/80 text-red-400 border border-red-900 animate-pulse'}`}>
                          {row.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-450 text-[10px]">{row.created_at}</td>
                    </tr>
                  ))}
                  {punishmentData.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-slate-555 uppercase">No gallows failures logged yet. Clear spelling records!</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'terminal' && (
          <div className="space-y-6">
            <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl">
              <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest mb-1">
                ⚙️ Executable SELECT Playground Console
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Execute SELECT statements using the mock database interpreter. Filters like <code className="text-cyan-500 font-mono">WHERE</code>, <code className="text-cyan-500 font-mono">ORDER BY</code>, and <code className="text-cyan-500 font-mono">LIMIT</code> are parsed and rendered real-time in tabular matrix grids.
              </p>
            </div>

            {/* SQL Terminal Shell Prompt */}
            <form onSubmit={handleExecuteSQL} className="space-y-3">
              <div className="bg-slate-95 * bg-slate-950 rounded-xl border border-slate-850 p-4 flex flex-col font-mono text-sm leading-relaxed text-slate-300">
                <div className="flex items-center gap-2 text-slate-500 text-xs mb-2 border-b border-slate-900 pb-2 select-none">
                  <span>mysql&gt;</span>
                  <span className="text-slate-600">INPUT AREA</span>
                </div>
                <input
                  type="text"
                  required
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                  className="w-full bg-transparent border-none outline-none font-bold text-cyan-400 caret-cyan-500 font-mono text-[13px] tracking-wide"
                  style={{ minWidth: '100%' }}
                  id="sql-cli-input"
                  placeholder="SELECT * FROM scores ORDER BY score DESC LIMIT 5;"
                />
              </div>

              <div className="flex flex-wrap justify-between items-center gap-3">
                {/* Visual Preset selection helpers */}
                <div className="flex flex-wrap gap-2">
                  <span className="text-slate-500 font-mono text-xs items-center inline-flex select-none">Presets:</span>
                  <button
                    type="button"
                    onClick={() => loadPreset("SELECT * FROM users;")}
                    className="px-2 py-1 bg-slate-950 border border-slate-800 text-slate-400 font-mono text-[10px] rounded hover:border-slate-700 hover:text-white"
                  >
                    Select Users
                  </button>
                  <button
                    type="button"
                    onClick={() => loadPreset("SELECT * FROM scores ORDER BY score DESC LIMIT 5;")}
                    className="px-2 py-1 bg-slate-950 border border-slate-800 text-slate-400 font-mono text-[10px] rounded hover:border-slate-700 hover:text-white"
                  >
                    Leaderboards
                  </button>
                  <button
                    type="button"
                    onClick={() => loadPreset("SELECT * FROM scores WHERE category = 'Technology';")}
                    className="px-2 py-1 bg-slate-950 border border-slate-800 text-slate-400 font-mono text-[10px] rounded hover:border-slate-700 hover:text-white"
                  >
                    Technology Scores
                  </button>
                  <button
                    type="button"
                    onClick={() => loadPreset("SELECT * FROM punishments ORDER BY punishment_id DESC;")}
                    className="px-2 py-1 bg-slate-950 border border-red-950/40 hover:border-red-900 text-red-400 font-mono text-[10px] rounded hover:bg-slate-900 focus:outline-none"
                  >
                    Punishments Log
                  </button>
                </div>

                <button
                  type="submit"
                  className="bg-cyan-500 hover:brightness-110 text-slate-950 px-5 py-2 rounded-lg font-bold font-mono text-xs tracking-wider cursor-pointer shadow-lg shadow-cyan-500/10"
                  id="btn-sql-execute"
                >
                  ⚡ EXECUTE QUERY
                </button>
              </div>
            </form>

            {/* SQL Terminal Response shell block */}
            {terminalResults && (
              <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950 flex flex-col font-mono text-xs animate-fade-in shadow-inner">
                <div className="bg-slate-900 px-4 py-2 text-slate-500 text-[10px] uppercase border-b border-slate-850 font-bold select-none">
                  📟 DATABASE COMPILER SHELL OUTPUT
                </div>

                {terminalResults.error ? (
                  <div className="p-4 text-red-400 break-words whitespace-pre-wrap leading-relaxed">
                    ERROR: {terminalResults.error}
                  </div>
                ) : terminalResults.rows.length === 0 ? (
                  <div className="p-4 text-slate-500 tracking-wide text-center uppercase select-none">
                     No matching row entries compiled in database. Empty set (0.00 sec)
                  </div>
                ) : (
                  <div className="overflow-x-auto p-4 select-text">
                    <table className="w-full text-left font-mono text-[11px] text-slate-300 divide-y divide-slate-800 border-collapse">
                      <thead>
                        <tr>
                          {terminalResults.columns.map((col, idx) => (
                            <th key={idx} className="pb-2 text-slate-500 font-bold uppercase tracking-wider pr-4">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850">
                        {terminalResults.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-900/20">
                            {terminalResults.columns.map((col, cIdx) => (
                              <td key={cIdx} className="py-2 pr-4 text-cyan-300 break-all max-w-[200px] whitespace-normal">
                                {String(row[col])}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="text-[10px] text-slate-600 mt-4 pt-2 border-t border-slate-900 select-none">
                      {terminalResults.rows.length} rows in set successfully compiled (0.02 sec)
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bg-slate-950 border-t border-slate-850 px-6 py-3 font-mono text-[10px] text-slate-500 flex justify-between select-none">
        <span>STATUS: ACTIVE CONNECTION</span>
        <span>MySQL Engine: InnoDB</span>
      </div>
    </div>
  );
};
