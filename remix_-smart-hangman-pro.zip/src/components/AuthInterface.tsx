// src/components/AuthInterface.tsx
import React, { useState } from 'react';
import { authenticateUserInMockDB, registerUserInMockDB } from '../utils/dbMock';
import { playSynthSound } from '../utils/audio';
import { AppTheme } from '../utils/themes';

interface AuthInterfaceProps {
  onSuccess: (user: { user_id: number; username: string }) => void;
  onBypass: () => void;
  theme: AppTheme;
}

export const AuthInterface: React.FC<AuthInterfaceProps> = ({ onSuccess, onBypass, theme }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText(null);
    setSuccessText(null);
    playSynthSound('click');

    if (isLogin) {
      const res = authenticateUserInMockDB(username, password);
      if (res.success && res.user) {
        setSuccessText("Authentication approved!");
        playSynthSound('win');
        setTimeout(() => onSuccess(res.user!), 800);
      } else {
        setErrorText(res.message);
        playSynthSound('fail');
      }
    } else {
      const res = registerUserInMockDB(username, password);
      if (res.success) {
        setSuccessText("User registered successfully! You can login now.");
        playSynthSound('win');
        setIsLogin(true);
        setPassword('');
      } else {
        setErrorText(res.message);
        playSynthSound('fail');
      }
    }
  };

  return (
    <div className={`w-full max-w-md ${theme.bgCard} border rounded-2xl p-8 shadow-2xl relative overflow-hidden transition-colors duration-500`}>
      {/* Decorative header line */}
      <div className={`absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r ${theme.gradientAccent}`} />
      
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold tracking-tight text-white mb-2">
          SMART HANGMAN PRO
        </h2>
        <span className="inline-block px-3 py-1 bg-black/30 border border-slate-800/80 text-slate-400 font-mono text-xs rounded-full">
          🕹️ Standard OS Gateway Console
        </span>
      </div>

      <div className={`flex ${theme.bgInner} p-1 rounded-lg mb-6 border transition-all duration-500`}>
        <button
          onClick={() => { playSynthSound('click'); setIsLogin(true); setErrorText(null); setSuccessText(null); }}
          className={`flex-1 py-2 text-sm font-semibold rounded-md transition-all duration-150 cursor-pointer ${isLogin ? `${theme.bgAccent} ${theme.accentShadow}` : 'text-slate-400 hover:text-white'}`}
          id="btn-tab-login"
        >
          LOGIN
        </button>
        <button
          onClick={() => { playSynthSound('click'); setIsLogin(false); setErrorText(null); setSuccessText(null); }}
          className={`flex-1 py-2 text-sm font-semibold rounded-md transition-all duration-150 cursor-pointer ${!isLogin ? `${theme.bgAccent} ${theme.accentShadow}` : 'text-slate-400 hover:text-white'}`}
          id="btn-tab-register"
        >
          REGISTER
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-slate-300 font-medium text-sm mb-1.5" htmlFor="auth-username">
            Username
          </label>
          <input
            id="auth-username"
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className={`w-full ${theme.bgInner} border rounded-lg px-4 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 transition-colors`}
            placeholder="e.g. HangmanPro"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-medium text-sm mb-1.5" htmlFor="auth-password">
            Password
          </label>
          <input
            id="auth-password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`w-full ${theme.bgInner} border rounded-lg px-4 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 transition-colors`}
            placeholder="••••••••"
          />
        </div>

        {errorText && (
          <div className="p-3 bg-red-950/40 border border-red-800 text-red-400 font-mono text-xs rounded-lg text-center">
            {errorText}
          </div>
        )}

        {successText && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-400 font-mono text-xs rounded-lg text-center">
            {successText}
          </div>
        )}

        <button
          type="submit"
          className={`w-full bg-gradient-to-r ${theme.gradientAccent} text-slate-950 font-black py-3 px-4 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer shadow-lg ${theme.accentShadow}`}
          id="btn-auth-submit"
        >
          {isLogin ? 'CONNECT SESSION' : 'SUBMIT REGISTRATION'}
        </button>
      </form>

      <div className="relative flex py-6 items-center">
        <div className="flex-grow border-t border-slate-800/80"></div>
        <span className="flex-shrink mx-4 text-slate-600 font-mono text-xs uppercase">or</span>
        <div className="flex-grow border-t border-slate-800/80"></div>
      </div>

      <button
        onClick={onBypass}
        className={`w-full ${theme.bgInner} hover:bg-white/5 text-slate-300 border hover:border-slate-700/80 font-medium py-3 px-4 rounded-lg transition-colors cursor-pointer text-sm`}
        id="btn-auth-bypass"
      >
        Play Offline (Guest Mode)
      </button>

      <div className="text-center mt-6 text-slate-500 text-xs font-mono">
        💡 Seeds: <span className={`${theme.textAccent}`}>SpeedyGuesser</span> / <span className="text-indigo-400">pass123</span>
      </div>
    </div>
  );
};
