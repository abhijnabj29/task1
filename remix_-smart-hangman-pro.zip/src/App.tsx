// src/App.tsx
import { useState, useEffect } from 'react';
import { AuthInterface } from './components/AuthInterface';
import { SmartHangmanConsole } from './components/SmartHangmanConsole';
import { DatabaseExplorer } from './components/DatabaseExplorer';
import { DocViewer } from './components/DocViewer';
import { playSynthSound, setAudioVolume, setAudioMuted, setSynthWaveform, getAudioSettings } from './utils/audio';
import { APP_THEMES, AppTheme } from './utils/themes';
import { 
  Gamepad2, 
  Database, 
  FileText, 
  LogOut, 
  Volume2,
  VolumeX,
  Sliders,
  Sparkles,
  Music
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<{ user_id: number; username: string } | null>(null);
  const [activeSegment, setActiveSegment] = useState<'console' | 'mysql' | 'docs'>('console');
  
  // Theme States
  const [activeTheme, setActiveTheme] = useState<AppTheme>(() => {
    const saved = localStorage.getItem('hangman_theme');
    if (saved) {
      const found = APP_THEMES.find(t => t.id === saved);
      if (found) return found;
    }
    return APP_THEMES[0]; // Classic Obsidian
  });

  // Audio configuration states
  const [volume, setVolume] = useState(0.4);
  const [isMuted, setIsMuted] = useState(false);
  const [waveform, setWaveform] = useState<OscillatorType>('sine');
  const [showAudioPanel, setShowAudioPanel] = useState(false);

  // Scoring update signal trigger to tell DatabaseExplorer to reload tables live!
  const [scoreUpdateCounter, setScoreUpdateCounter] = useState(0);

  // Synchronize audio configuration values on load and change
  useEffect(() => {
    setAudioVolume(volume);
    setAudioMuted(isMuted);
    setSynthWaveform(waveform);
  }, [volume, isMuted, waveform]);

  const handleThemeChange = (themeId: string) => {
    const found = APP_THEMES.find(t => t.id === themeId);
    if (found) {
      setActiveTheme(found);
      localStorage.setItem('hangman_theme', found.id);
      playSynthSound('success');
    }
  };

  const handleAuthSuccess = (loggedUser: { user_id: number; username: string }) => {
    setUser(loggedUser);
    setActiveSegment('console');
  };

  const handleGuestBypass = () => {
    playSynthSound('click');
    setUser({ user_id: 0, username: 'Guest_User' });
    setActiveSegment('console');
  };

  const handleLogout = () => {
    playSynthSound('click');
    setUser(null);
  };

  const selectTab = (segment: 'console' | 'mysql' | 'docs') => {
    playSynthSound('click');
    setActiveSegment(segment);
  };

  const testAudioTone = () => {
    playSynthSound('hint');
  };

  return (
    <div className={`min-h-screen ${activeTheme.bgScreen} flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white transition-colors duration-500`}>
      {/* Upper Navigation Header Frame */}
      <header className={`${activeTheme.bgCard} border-b ${activeTheme.border} px-6 py-4 sticky top-0 z-30 shadow-md transition-colors duration-500`}>
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-4">
          
          {/* Logo Brand area */}
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${activeTheme.gradientAccent} flex items-center justify-center shadow-lg ${activeTheme.accentShadow} transition-all duration-500`}>
              <span className="font-mono text-slate-950 font-black text-lg select-none">S</span>
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-2 leading-none">
                SMART HANGMAN PRO
              </h1>
              <span className="text-[10px] text-slate-500 font-mono block tracking-wider uppercase mt-1">
                Academic showcase Console • v1.2.0
              </span>
            </div>
          </div>

          {/* Interactive Themes and Audio Control deck */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            
            {/* Dynamic Theme Picker */}
            <div className="flex items-center bg-black/40 border border-slate-800/80 p-1.5 rounded-xl gap-1">
              <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-wider px-2">
                THEME:
              </span>
              <div className="flex gap-1">
                {APP_THEMES.map((theme) => (
                  <button
                    key={theme.id}
                    title={theme.name}
                    onClick={() => handleThemeChange(theme.id)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-sm transition-all relative ${activeTheme.id === theme.id ? 'bg-white/10 border border-white/25 scale-110 shadow-sm' : 'hover:bg-white/5 opacity-60 hover:opacity-100'}`}
                  >
                    <span>{theme.icon}</span>
                    {activeTheme.id === theme.id && (
                      <span className="absolute -bottom-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Synth Control Deck */}
            <div className="relative">
              <button
                onClick={() => { playSynthSound('click'); setShowAudioPanel(!showAudioPanel); }}
                className={`px-3 py-2 bg-black/40 border border-slate-800/80 rounded-xl flex items-center gap-1.5 font-mono text-xs text-slate-400 hover:text-white transition-colors cursor-pointer ${showAudioPanel ? 'border-indigo-500/50 text-indigo-400' : ''}`}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                <span>AUDIO DECK</span>
              </button>

              {showAudioPanel && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-2xl z-50 text-slate-300 font-mono text-xs space-y-4 animate-fade-in">
                  <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                    <span className="font-bold text-white flex items-center gap-1">
                      <Sliders className="w-3.5 h-3.5 text-indigo-400" /> Synth Console
                    </span>
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${isMuted ? 'bg-rose-950 text-rose-400 border border-rose-900' : 'bg-emerald-950 text-emerald-400 border border-emerald-900'}`}
                    >
                      {isMuted ? 'MUTED' : 'LIVE'}
                    </button>
                  </div>

                  {/* Volume Slider */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>VOLUME</span>
                      <span>{Math.round(volume * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={volume}
                      disabled={isMuted}
                      onChange={(e) => setVolume(parseFloat(e.target.value))}
                      className="w-full accent-emerald-500 bg-slate-950 rounded-lg cursor-pointer h-1"
                    />
                  </div>

                  {/* Oscillator Core Selector */}
                  <div className="space-y-1">
                    <div className="text-[10px] text-slate-500">SYNTH OSCILLATOR WAVE</div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(['sine', 'triangle', 'square', 'sawtooth'] as OscillatorType[]).map((wave) => (
                        <button
                          key={wave}
                          disabled={isMuted}
                          onClick={() => { setWaveform(wave); playSynthSound('click'); }}
                          className={`py-1 px-1.5 rounded border text-[10px] font-bold uppercase tracking-wider text-center transition-colors ${waveform === wave ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'}`}
                        >
                          {wave === 'sine' ? 'Pure Sine' : wave === 'triangle' ? 'Soft Tri' : wave === 'square' ? 'Arcade Sq' : 'Saw Lead'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-850 flex gap-2">
                    <button
                      onClick={testAudioTone}
                      disabled={isMuted}
                      className="flex-1 py-1.5 bg-indigo-950 border border-indigo-900 hover:bg-indigo-900/40 text-indigo-400 rounded text-[10px] font-bold tracking-wider uppercase transition-colors"
                    >
                      ⚡ Test Beep
                    </button>
                    <button
                      onClick={() => setShowAudioPanel(false)}
                      className="px-2 py-1.5 bg-slate-950 border border-slate-800 text-slate-500 hover:text-slate-300 rounded text-[10px] transition-colors"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Connected status panel */}
            {user && (
              <div className="flex items-center gap-4">
                <div className="bg-black/40 border border-slate-800/80 px-4 py-2 rounded-xl flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <div className="text-xs">
                    <span className="text-slate-500 font-mono mr-1">connected:</span>
                    <span className="text-slate-300 font-bold">{user.username}</span>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="px-3.5 py-2 bg-black/40 hover:bg-red-950/20 text-slate-400 hover:text-red-400 border border-slate-800/80 hover:border-red-900 rounded-xl transition-all font-semibold font-mono text-xs flex items-center gap-1.5 cursor-pointer"
                  id="btn-header-logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  LOGOUT
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Body Application Interface */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col items-center justify-center">
        {!user ? (
          <AuthInterface onSuccess={handleAuthSuccess} onBypass={handleGuestBypass} theme={activeTheme} />
        ) : (
          <div className="w-full flex flex-col gap-6" id="dashboard-client-frame">
            {/* Visual segments navigation tabs */}
            <div className={`flex bg-black/30 p-1.5 rounded-xl border ${activeTheme.border} max-w-xl shadow-lg`}>
              <button
                onClick={() => selectTab('console')}
                className={`flex-1 py-2.5 px-4 rounded-lg font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${activeSegment === 'console' ? `${activeTheme.bgAccent} ${activeTheme.accentShadow}` : 'text-slate-450 hover:text-white'}`}
                id="btn-tab-gameplay"
              >
                <Gamepad2 className="w-4 h-4" />
                Gamepad
              </button>
              <button
                onClick={() => selectTab('mysql')}
                className={`flex-1 py-2.5 px-4 rounded-lg font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${activeSegment === 'mysql' ? `${activeTheme.bgAccent} ${activeTheme.accentShadow}` : 'text-slate-450 hover:text-white'}`}
                id="btn-tab-mysql"
              >
                <Database className="w-4 h-4" />
                MySQL DB Console
              </button>
              <button
                onClick={() => selectTab('docs')}
                className={`flex-1 py-2.5 px-4 rounded-lg font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${activeSegment === 'docs' ? `${activeTheme.bgAccent} ${activeTheme.accentShadow}` : 'text-slate-450 hover:text-white'}`}
                id="btn-tab-docs"
              >
                <FileText className="w-4 h-4" />
                Project reports
              </button>
            </div>

            {/* Displaying active components based on tab route selections */}
            <div className="transition-all duration-300 animate-fade-in relative z-10 w-full">
              {activeSegment === 'console' && (
                <SmartHangmanConsole
                  currentUser={user}
                  onScoresUpdated={() => setScoreUpdateCounter((prev) => prev + 1)}
                  theme={activeTheme}
                />
              )}

              {activeSegment === 'mysql' && (
                <DatabaseExplorer scoreTrigger={scoreUpdateCounter} theme={activeTheme} />
              )}

              {activeSegment === 'docs' && (
                <DocViewer theme={activeTheme} />
              )}
            </div>
          </div>
        )}
      </main>

      {/* Standard structural footer block */}
      <footer className="bg-black/50 border-t border-slate-900/50 py-6 px-6 text-center text-[10px] text-slate-600 font-mono select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <span>Smart Hangman Pro • Python 3 & MySQL Desktop Project Suite</span>
          <div className="flex items-center gap-2">
            <span>Designed with high-fidelity for nagrajkc6@gmail.com</span>
            <span className="text-slate-500">•</span>
            <span className={`font-semibold ${activeTheme.textAccent}`}>Active: {activeTheme.name}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

