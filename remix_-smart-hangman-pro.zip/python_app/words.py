# words.py
# Part of Smart Hangman Pro
# Contains categorized word list and hints grouped by difficulty levels.

WORD_DATABASE = {
    "Technology": {
        "easy": [
            {"word": "MOUSE", "hint": "A hand-held pointing device used for computers."},
            {"word": "EMAIL", "hint": "Electronic mail used to exchange messages over internet."},
            {"word": "ROUTER", "hint": "A device that forwards data packets between computer networks."},
            {"word": "SCREEN", "hint": "A flat surface on which pictures or words are shown on a monitor."}
        ],
        "medium": [
            {"word": "DATABASE", "hint": "An organized collection of structured information or data."},
            {"word": "PYTHON", "hint": "A versatile high-level OOP programming language."},
            {"word": "FIREWALL", "hint": "A network security system that monitors and controls incoming traffic."},
            {"word": "INTERNET", "hint": "A global computer network providing a variety of information."}
        ],
        "hard": [
            {"word": "ALGORITHM", "hint": "A process or set of rules to be followed in calculations or problem-solving."},
            {"word": "KUBERNETES", "hint": "An open-source container orchestration system for automating application deployment."},
            {"word": "CRYPTOGRAPHY", "hint": "The practice and study of techniques for secure communication."},
            {"word": "CYBERSECURITY", "hint": "The practice of protecting systems, networks, and programs from digital attacks."}
        ]
    },
    "Sports": {
        "easy": [
            {"word": "SOCCER", "hint": "A game played by two teams of eleven players with a round ball."},
            {"word": "TENNIS", "hint": "A racket sport played individually against a single opponent or between two teams of two."},
            {"word": "GOLF", "hint": "A club-and-ball sport played on a course with 9 or 18 holes."},
            {"word": "CHESS", "hint": "A two-player strategy board game played on a checkered board."}
        ],
        "medium": [
            {"word": "BASEBALL", "hint": "A bat-and-ball game played between two opposing teams who take turns batting and fielding."},
            {"word": "CRICKET", "hint": "A bat-and-ball game played on a field with a 22-yard pitch in the center."},
            {"word": "ATHLETE", "hint": "A person who is proficient in sports and other forms of physical exercise."},
            {"word": "MARATHON", "hint": "A long-distance running race with an official distance of 42.195 kilometers."}
        ],
        "hard": [
            {"word": "GYMNASTICS", "hint": "Exercises developing or displaying physical agility and coordination."},
            {"word": "BADMINTON", "hint": "A racket sport played using shuttlecocks across a net."},
            {"word": "VELODROME", "hint": "An arena for track cycling, featuring steep banked oval tracks."},
            {"word": "DECATHLON", "hint": "An athletic event taking place over two days, in which contestants compete in ten track and field events."}
        ]
    },
    "Movies": {
        "easy": [
            {"word": "AVATAR", "hint": "A high-grossing sci-fi film set on the lush moon of Pandora."},
            {"word": "TITANIC", "hint": "A romantic disaster movie of an unsinkable ship."},
            {"word": "BATMAN", "hint": "A wealthy American playboy who fights crime in Gotham City."},
            {"word": "FROZEN", "hint": "An animated musical fantasy film featuring Elsa and Anna."}
        ],
        "medium": [
            {"word": "INCEPTION", "hint": "A mental heist thriller where thieves enter people's dreams."},
            {"word": "GLADIATOR", "hint": "An epic historical drama following Maximus Decimus Meridius."},
            {"word": "AVENGERS", "hint": "A team of extraordinary superheroes assemble to save Earth."},
            {"word": "WHIPLASH", "hint": "A music student's struggle under an abusive jazz instructor."}
        ],
        "hard": [
            {"word": "INTERSTELLAR", "hint": "An epic sci-fi space odyssey involving black holes and wormholes."},
            {"word": "CASABLANCA", "hint": "A classic romantic drama set during World War II in Morocco."},
            {"word": "PULPFICTION", "hint": "A Neo-noir crime film directed by Quentin Tarantino."},
            {"word": "SCHINDLERSLIST", "hint": "An epic historical drama based on the life of an industrialist during WWII."}
        ]
    },
    "Animals": {
        "easy": [
            {"word": "LION", "hint": "The king of the jungle."},
            {"word": "ZEBRA", "hint": "An African wild horse with black-and-white stripes."},
            {"word": "DOLPHIN", "hint": "A highly intelligent marine mammal known for its playful behavior."},
            {"word": "RABBIT", "hint": "A small mammal with long ears, long hind legs, and a short fluffy tail."}
        ],
        "medium": [
            {"word": "KANGAROO", "hint": "A large jumping marsupial from Australia."},
            {"word": "PENGUIN", "hint": "A flightless aquatic bird living almost exclusively in the Southern Hemisphere."},
            {"word": "CHIMPANZEE", "hint": "Great apes native to the forests of tropical Africa, sharing 98% human DNA."},
            {"word": "OCTOPUS", "hint": "A soft-bodied, eight-limbed mollusk."}
        ],
        "hard": [
            {"word": "CAMELOPARD", "hint": "The archaic historical name for a giraffe."},
            {"word": "CHAMELEON", "hint": "A highly specialized lizard famous for its color-changing ability."},
            {"word": "PLATYPUS", "hint": "A semiaquatic egg-laying mammal endemic to eastern Australia."},
            {"word": "AXOLOTL", "hint": "An aquatic salamander known for its capacity to regenerate limbs."}
        ]
    }
}
