# main.py
# Smart Hangman Pro - Primary Application Module (Tkinter GUI Client)
# Designed with standard OOP structure, MVC-like rendering separation, and MySQL integration.

import sys
import random
import tkinter as tk
from tkinter import ttk, messagebox
import math

# Try importing database manager and words
try:
    from database import DatabaseManager
    from words import WORD_DATABASE
except ImportError:
    # Inline fail-safe declarations if module loaded independently
    WORD_DATABASE = {
        "General": {
            "easy": [{"word": "APPLE", "hint": "A crisp, round, red or green fruit."}],
            "medium": [{"word": "PYTHON", "hint": "A versatile high-level OOP programming language."}],
            "hard": [{"word": "ALGORITHM", "hint": "A step-by-step problem-solving procedure."}]
        }
    }
    class DatabaseManager:
        def __init__(self, **kwargs): pass
        def connect(self): return False
        def close(self): pass

class SmartHangmanApp(tk.Tk):
    """
    Main Application Window class. Coordinates navigation between
    views: Authentication, Game Setup, Active Gameplay, Leaderboard, and Stats.
    """
    def __init__(self):
        super().__init__()
        self.title("Smart Hangman Pro")
        self.geometry("900x650")
        self.minsize(800, 600)
        self.configure(bg="#1E293B")  # Slate dark primary background
        
        # Configure overall themes
        self._set_style()
        
        # Core States
        self.db = DatabaseManager()
        self.db_connected = self.db.connect()
        self.current_user = None  # None when guest or unauthenticated
        
        # Audio feedback flag
        self.sound_enabled = True
        
        # Initial View Setup
        self.current_frame = None
        self.show_auth_view()

    def _set_style(self):
        """Applies a high-fidelity dark slate theme alignment configurations to standard tkinter elements."""
        style = ttk.Style(self)
        style.theme_use("clam")
        
        # Base settings
        style.configure(".", background="#1E293B", foreground="#F8FAFC")
        style.configure("TFrame", background="#1E293B")
        
        # Label designs
        style.configure("TLabel", background="#1E293B", foreground="#F8FAFC", font=("Helvetica", 11))
        style.configure("Header.TLabel", font=("Helvetica", 22, "bold"), background="#1E293B", foreground="#38BDF8")
        style.configure("Sub.TLabel", font=("Helvetica", 14), background="#1E293B", foreground="#94A3B8")
        
        # Buttons configurations
        style.configure("TButton", font=("Helvetica", 11, "bold"), background="#0F172A", foreground="#38BDF8", borderwidth=1)
        style.map("TButton",
                  background=[("active", "#38BDF8"), ("pressed", "#0284C7")],
                  foreground=[("active", "#0F172A"), ("pressed", "#FFFFFF")])
                  
        style.configure("Action.TButton", background="#38BDF8", foreground="#0F172A", font=("Helvetica", 12, "bold"))
        style.map("Action.TButton",
                  background=[("active", "#7DD3FC")],
                  foreground=[("active", "#0F172A")])

        # Entry fields
        style.configure("TEntry", fieldbackground="#0F172A", foreground="#F8FAFC", insertcolor="#F8FAFC")
        
        # Notebook (tabs)
        style.configure("TNotebook", background="#0F172A", borderwidth=0)
        style.configure("TNotebook.Tab", background="#1E293B", foreground="#94A3B8", font=("Helvetica", 10, "bold"), padding=[12, 4])
        style.map("TNotebook.Tab", background=[("selected", "#0F172A")], foreground=[("selected", "#38BDF8")])

    def switch_frame(self, frame_class, *args, **kwargs):
        """Standard routing framework to clean up and instantiate consecutive app frames."""
        if self.current_frame:
            self.current_frame.destroy()
        self.current_frame = frame_class(self, *args, **kwargs)
        self.current_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

    def show_auth_view(self):
        self.switch_frame(AuthFrame)

    def show_menu_view(self):
        self.switch_frame(MenuFrame)

    def start_game(self, category, difficulty):
        self.switch_frame(GamePlayFrame, category, difficulty)

    def show_leaderboard(self):
        self.switch_frame(LeaderboardFrame)

    def show_stats(self):
        self.switch_frame(StatsFrame)

    def play_sound(self, sound_type):
        """Simulates native sound effects using system bell triggers fallback."""
        if not self.sound_enabled:
            return
        
        # Cross-platform sound buzzer
        try:
            if sys.platform == "win32":
                import winsound
                # Pitch frequency adjustments mapping success or error
                if sound_type == "success":
                    winsound.Beep(988, 120)  # High double-beep
                    winsound.Beep(1318, 180)
                elif sound_type == "fail":
                    winsound.Beep(220, 300)  # Low flat buzz
                elif sound_type == "win":
                    winsound.Beep(523, 100)
                    winsound.Beep(659, 100)
                    winsound.Beep(784, 100)
                    winsound.Beep(1046, 250)
                elif sound_type == "lose":
                    winsound.Beep(293, 150)
                    winsound.Beep(220, 150)
                    winsound.Beep(146, 350)
            else:
                self.bell()  # System buzzer on macOS/Linux fallback
        except Exception:
            pass  # Suppress audio driver execution errors gracefully


class AuthFrame(ttk.Frame):
    """
    Coordinates user registration and login behaviors.
    Includes a fail-safe offline mode if MySQL connectivity is absent.
    """
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        
        # Content centered card layout
        card = ttk.Frame(self)
        card.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        # Title
        title_label = ttk.Label(card, text="SMART HANGMAN PRO", style="Header.TLabel")
        title_label.pack(pady=(0, 5))
        
        sub_label = ttk.Label(card, text="Professional Gaming & Statistics Console", style="Sub.TLabel")
        sub_label.pack(pady=(0, 25))

        # DB Connection Status Indicator
        status_text = "● Connected to Database" if master.db_connected else "⚠ Connection Failed: Offline Mode Enabled"
        status_color = "#10B981" if master.db_connected else "#F59E0B"
        status_lbl = tk.Label(card, text=status_text, fg=status_color, bg="#1E293B", font=("Helvetica", 9, "bold"))
        status_lbl.pack(pady=(0, 15))

        # Username Field
        ttk.Label(card, text="Username:").pack(anchor=tk.W, pady=(5, 2))
        self.username_entry = ttk.Entry(card, width=30, font=("Helvetica", 11))
        self.username_entry.pack(pady=(0, 10))
        
        # Password Field
        ttk.Label(card, text="Password:").pack(anchor=tk.W, pady=(5, 2))
        self.password_entry = ttk.Entry(card, width=30, show="*", font=("Helvetica", 11))
        self.password_entry.pack(pady=(0, 20))

        # Login and Register Actions panel
        actions_grid = ttk.Frame(card)
        actions_grid.pack(fill=tk.X, pady=5)
        
        login_btn = ttk.Button(actions_grid, text="LOGIN", style="Action.TButton", command=self.handle_login)
        login_btn.grid(row=0, column=0, padx=5, sticky="ew")
        
        register_btn = ttk.Button(actions_grid, text="REGISTER", command=self.handle_register)
        register_btn.grid(row=0, column=1, padx=5, sticky="ew")
        
        actions_grid.columnconfigure(0, weight=1)
        actions_grid.columnconfigure(1, weight=1)

        # Developer Bypass Play-As-Guest option
        guest_btn = ttk.Button(card, text="Play Offline (Guest Mode)", command=self.bypass_auth, style="TButton")
        guest_btn.pack(pady=(15, 0), fill=tk.X)

    def handle_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not self.master.db_connected:
            messagebox.showwarning("Offline Mode", "Running locally unsupported database. Logged in as Guest.")
            self.bypass_auth()
            return
            
        success, result_or_msg = self.master.db.authenticate_user(username, password)
        if success:
            self.master.current_user = result_or_msg  # Contains: {'user_id': X, 'username': '...'}
            messagebox.showinfo("Welcome!", f"Access granted. Welcome back, {username}!")
            self.master.show_menu_view()
        else:
            messagebox.showerror("Auth Error", result_or_msg)

    def handle_register(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not self.master.db_connected:
            messagebox.showerror("Offline Error", "Cannot register users without database connectivity.")
            return
            
        success, msg = self.master.db.register_user(username, password)
        if success:
            messagebox.showinfo("Success", msg)
            self.username_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Error", msg)

    def bypass_auth(self):
        self.master.current_user = {"user_id": 0, "username": "Guest_User"}
        self.master.show_menu_view()


class MenuFrame(ttk.Frame):
    """
    Main dashboard menu after successful login.
    Enables choosing game categories, scoring systems, difficulty, and navigating to reports.
    """
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        
        header_text = f"CONSOLE: Welcome, {master.current_user['username']}!"
        ttk.Label(self, text=header_text, style="Header.TLabel").pack(pady=(10, 5))
        ttk.Label(self, text="Configure your active gaming grid settings below:", style="Sub.TLabel").pack(pady=(0, 20))

        # Main Hub Layout Grid
        hub_grid = ttk.Frame(self)
        hub_grid.pack(fill=tk.BOTH, expand=True, pady=10)
        hub_grid.columnconfigure(0, weight=1)
        hub_grid.columnconfigure(1, weight=1)

        # LEFT COLUMN - Setup Card
        setup_card = ttk.LabelFrame(hub_grid, text=" GAME PARAMETERS ", padding=20)
        setup_card.grid(row=0, column=0, padx=15, pady=10, sticky="nsew")

        # Category Dropdown Selection
        ttk.Label(setup_card, text="Select Game Category:", font=("Helvetica", 11, "bold")).pack(anchor=tk.W, pady=(5, 5))
        self.cat_var = tk.StringVar(value=list(WORD_DATABASE.keys())[0])
        cat_combo = ttk.Combobox(setup_card, textvariable=self.cat_var, values=list(WORD_DATABASE.keys()), state="readonly", font=("Helvetica", 11))
        cat_combo.pack(pady=(0, 15), fill=tk.X)

        # Difficulty Level Radiobuttons
        ttk.Label(setup_card, text="Select Difficulty Level:", font=("Helvetica", 11, "bold")).pack(anchor=tk.W, pady=(5, 5))
        self.diff_var = tk.StringVar(value="medium")
        
        for diff in ["easy", "medium", "hard"]:
            # Style each radio button matching dark UI
            r_btn = tk.Radiobutton(setup_card, text=diff.capitalize(), variable=self.diff_var, value=diff,
                                   bg="#1E293B", fg="#F8FAFC", selectcolor="#0F172A", activebackground="#1E293B",
                                   activeforeground="#38BDF8", font=("Helvetica", 10, "bold"))
            r_btn.pack(anchor=tk.W, pady=2)

        # Play Button trigger
        play_btn = ttk.Button(setup_card, text="INITIALIZE GAME", style="Action.TButton", command=self.trigger_play)
        play_btn.pack(pady=(25, 0), fill=tk.X)

        # RIGHT COLUMN - Action Links Panel
        nav_card = ttk.LabelFrame(hub_grid, text=" CONTROLLER LINKS ", padding=20)
        nav_card.grid(row=0, column=1, padx=15, pady=10, sticky="nsew")

        ttk.Button(nav_card, text="🏆 LEADERBOARD RANKINGS", command=master.show_leaderboard).pack(pady=10, fill=tk.X)
        ttk.Button(nav_card, text="📊 GRAPHICAL ANALYTICS", command=master.show_stats).pack(pady=10, fill=tk.X)
        
        # Audio Settings switch
        self.sound_var = tk.BooleanVar(value=master.sound_enabled)
        sound_cb = tk.Checkbutton(nav_card, text="Enable Audio Synthesizer Toggle", variable=self.sound_var,
                                  bg="#1E293B", fg="#F8FAFC", selectcolor="#0F172A", activebackground="#1E293B",
                                  activeforeground="#38BDF8", font=("Helvetica", 10), command=self.toggle_sound)
        sound_cb.pack(pady=15, anchor=tk.W)

        # Sign out button
        signout_btn = ttk.Button(nav_card, text="Logout Session", command=master.show_auth_view, style="TButton")
        signout_btn.pack(side=tk.BOTTOM, fill=tk.X)

    def toggle_sound(self):
        self.master.sound_enabled = self.sound_var.get()

    def trigger_play(self):
        category = self.cat_var.get()
        difficulty = self.diff_var.get()
        self.master.start_game(category, difficulty)


class GamePlayFrame(ttk.Frame):
    """
    Main Game Board. Encapsulates OOP state machine for hangman:
    word picking, guess testing, hint deduction, hangman coordinate painting,
    score generation and session logging.
    """
    def __init__(self, master, category, difficulty):
        super().__init__(master)
        self.master = master
        self.category = category
        self.difficulty = difficulty
        
        # Loaded word configurations
        self.word_set = WORD_DATABASE[category][difficulty]
        self.current_word_data = None
        self.actual_word = ""
        self.hint_text = ""
        
        # Active gameplay stats
        self.guessed_characters = set()
        self.mistakes_remaining = 6
        self.current_score = 0
        self.hints_used = 0
        self.success_count = 0  # Words guessed this individual streak
        
        # Layout Division
        self._build_gameboard_layout()
        
        # Kickoff word loading
        self.load_new_word()

    def _build_gameboard_layout(self):
        """Constructs split-view pane (Left: Drawing canvas, Right: Text & keyboard stats)"""
        # Upper dashboard stats
        stats_bar = ttk.Frame(self)
        stats_bar.pack(fill=tk.X, pady=(0, 10))
        
        # Left HUD details
        lbl_info = f"Category: {self.category} | Difficulty: {self.difficulty.capitalize()}"
        ttk.Label(stats_bar, text=lbl_info, font=("Helvetica", 11, "bold"), foreground="#94A3B8").pack(side=tk.LEFT)
        
        # Right HUD details
        self.score_lbl = ttk.Label(stats_bar, text="Score: 0", font=("Helvetica", 11, "bold"), foreground="#10B981")
        self.score_lbl.pack(side=tk.RIGHT)

        # Split Container Grid
        main_layout = ttk.Frame(self)
        main_layout.pack(fill=tk.BOTH, expand=True)
        main_layout.columnconfigure(0, weight=2)
        main_layout.columnconfigure(1, weight=3)

        # LEFT CANVAS - Hangman graphics drawer
        canvas_box = ttk.LabelFrame(main_layout, text=" ANIMATION PLATFORM ", padding=10)
        canvas_box.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        
        self.canvas = tk.Canvas(canvas_box, bg="#0F172A", width=250, height=350, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        # RIGHT CONTROLLER - GUI Input
        board_box = ttk.Frame(main_layout, padding=10)
        board_box.grid(row=0, column=1, sticky="nsew")

        # Word representation
        self.word_display = tk.Label(board_box, text="_ _ _ _ _", font=("Courier", 32, "bold"), bg="#1E293B", fg="#38BDF8")
        self.word_display.pack(pady=20)

        # Hint box
        self.hint_lbl = ttk.Label(board_box, text="Hint: Click 'Get Hint' to view explanation", wraplength=400, justify=tk.CENTER, style="Sub.TLabel")
        self.hint_lbl.pack(pady=10)

        # Interactive Virtual Keyboard
        self.kb_frame = ttk.Frame(board_box)
        self.kb_frame.pack(fill=tk.BOTH, expand=True, pady=15)
        self._build_keyboard()

        # Bottom Utilities grid
        bottom_menu = ttk.Frame(board_box)
        bottom_menu.pack(fill=tk.X, side=tk.BOTTOM, pady=10)
        
        ttk.Button(bottom_menu, text="GET WORD HINT", command=self.reveal_hint).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_menu, text="SKIP WORD", command=self.load_new_word).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_menu, text="ABANDON GAME", command=self.exit_game_modal).pack(side=tk.RIGHT, padx=5)

    def _build_keyboard(self):
        """Standard 3-row layout virtual keyboard button mapper."""
        # Clean current buttons
        for child in self.kb_frame.winfo_children():
            child.destroy()
            
        rows = [
            "QWERTYUIOP",
            "ASDFGHJKL",
            "ZXCVBNM"
        ]
        
        self.key_buttons = {}
        for r_index, row in enumerate(rows):
            r_frame = ttk.Frame(self.kb_frame)
            r_frame.pack(pady=2)
            for ch in row:
                btn = ttk.Button(r_frame, text=ch, width=3, command=lambda c=ch: self.test_char_guess(c))
                btn.pack(side=tk.LEFT, padx=2)
                self.key_buttons[ch] = btn

    def load_new_word(self):
        """Picks random word that hasn't been guessed this run yet."""
        if not self.word_set:
            messagebox.showinfo("Reset", "Exhausted available category words! Shuffling base words list.")
            self.word_set = list(WORD_DATABASE[self.category][self.difficulty])
            
        self.current_word_data = random.choice(self.word_set)
        # Avoid immediate repetitiveness
        if len(self.word_set) > 1:
            while self.current_word_data["word"] == self.actual_word:
                self.current_word_data = random.choice(self.word_set)

        self.actual_word = self.current_word_data["word"].upper()
        self.hint_text = self.current_word_data["hint"]
        
        # Reset counters for this word iteration
        self.guessed_characters.clear()
        self.mistakes_remaining = 6
        self.hints_used = 0
        
        # Redraw
        self._build_keyboard()
        self.hint_lbl.configure(text="Hint: Click 'Get Hint' to view explanation", style="Sub.TLabel")
        self.refresh_word_field()
        self.paint_gallows()

    def refresh_word_field(self):
        """Dynamically displays underscores and matching correct character letters."""
        display_str = ""
        for character in self.actual_word:
            if character in self.guessed_characters:
                display_str += f"{character} "
            else:
                display_str += "_ "
        self.word_display.configure(text=display_str.strip())

    def test_char_guess(self, char):
        """Processes character evaluation step logic."""
        if char in self.guessed_characters or self.mistakes_remaining <= 0:
            return
            
        self.guessed_characters.add(char)
        self.key_buttons[char].configure(state=tk.DISABLED) # Lock guessed keys
        
        if char in self.actual_word:
            self.master.play_sound("success")
            self.refresh_word_field()
            
            # Check victory
            if all(ch in self.guessed_characters for ch in self.actual_word):
                self.process_word_win()
        else:
            self.master.play_sound("fail")
            self.mistakes_remaining -= 1
            self.paint_gallows()
            if self.mistakes_remaining <= 0:
                self.process_word_lose()

    def reveal_hint(self):
        """Displays hints, decrementing possible scores."""
        if self.hints_used >= 1:
            messagebox.showinfo("Limit", "You have already used the maximum hint allowable for this word.")
            return
        
        self.hints_used += 1
        self.hint_lbl.configure(text=f"HINT: {self.hint_text}", style="Header.TLabel") # Light up hint in cyan
        self.hint_lbl.configure(font=("Helvetica", 11, "italic"), foreground="#38BDF8")

    def paint_gallows(self):
        """Clears and draws modern, responsive graphic representation coordinates on canvas frame."""
        self.canvas.delete("all")
        
        # Color palettes
        wood_color = "#475569"  # Slate gallows
        rope_color = "#D97706"  # Rope orange
        scaffold_color = "#334155" # Background support bars
        body_color = "#38BDF8"  # Cyan stick-figure
        
        # Anchor base coordinates
        self.canvas.create_line(30, 320, 220, 320, fill=scaffold_color, width=6)  # Stand base
        self.canvas.create_line(70, 320, 70, 50, fill=wood_color, width=8)       # Gallow Post
        self.canvas.create_line(70, 50, 160, 50, fill=wood_color, width=8)       # Gallow Beam
        self.canvas.create_line(160, 50, 160, 90, fill=rope_color, width=3)      # Noose Loop
        self.canvas.create_line(70, 100, 120, 50, fill=wood_color, width=4)      # Support Angle brace
        
        parts_to_draw = 6 - self.mistakes_remaining
        
        # Match stick-figure items progressively
        if parts_to_draw >= 1:
            self.canvas.create_oval(140, 90, 180, 130, outline=body_color, width=4) # Head
        if parts_to_draw >= 2:
            self.canvas.create_line(160, 130, 160, 220, fill=body_color, width=4)   # Spine body
        if parts_to_draw >= 3:
            self.canvas.create_line(160, 150, 120, 180, fill=body_color, width=4)   # Left Arm
        if parts_to_draw >= 4:
            self.canvas.create_line(160, 150, 200, 180, fill=body_color, width=4)   # Right Arm
        if parts_to_draw >= 5:
            self.canvas.create_line(160, 220, 120, 280, fill=body_color, width=4)   # Left Leg
        if parts_to_draw >= 6:
            self.canvas.create_line(160, 220, 200, 280, fill=body_color, width=4)   # Right Leg

    def process_word_win(self):
        """Grants points adjusted by difficulty constraints, multiplier increments on consecutive streaks."""
        self.master.play_sound("win")
        
        # Difficulty scoring multipliers
        p_base = {"easy": 100, "medium": 200, "hard": 400}[self.difficulty]
        hint_penalty = 0.5 if self.hints_used > 0 else 1.0
        points_earned = int(p_base * hint_penalty)
        
        self.current_score += points_earned
        self.success_count += 1
        self.score_lbl.configure(text=f"Score: {self.current_score}")
        
        ans = messagebox.askyesno("CORRECT!", f"Fantastic! You decoded: {self.actual_word}\nEarned: +{points_earned} Points.\n\nContinue current winning streak?")
        if ans:
            self.load_new_word()
        else:
            self.conclude_session()

    def process_word_lose(self):
        self.master.play_sound("lose")
        ans = messagebox.askyesno("GAME OVER", f"You ran out of structural guesses!\nThe word was: {self.actual_word}\nFinal Score: {self.current_score}\n\nStart a new gaming grid?")
        if ans:
            # Keep score accumulation optionally reset depending on user preference
            self.current_score = 0
            self.success_count = 0
            self.score_lbl.configure(text="Score: 0")
            self.load_new_word()
        else:
            self.conclude_session()

    def conclude_session(self):
        """Serializes current score records back into SQL database."""
        user = self.master.current_user
        if user and user["user_id"] > 0 and self.master.db_connected:
            success = self.master.db.record_score(
                user_id=user["user_id"],
                score=self.current_score,
                category=self.category,
                difficulty=self.difficulty,
                words_guessed=self.success_count
            )
            if success:
                messagebox.showinfo("Stats Logged", f"High score of {self.current_score} saved successfully to cloud database!")
        else:
            messagebox.showinfo("Session Completed", f"Finished! Your final session score: {self.current_score}.\n(No MySQL connection; high score not recorded)")
            
        self.master.show_menu_view()

    def exit_game_modal(self):
        if messagebox.askyesno("Abandon", "Are you sure you want to exit? Unsaved progress will be vaporized."):
            self.master.show_menu_view()


class LeaderboardFrame(ttk.Frame):
    """
    Renders Top Players leaderboard.
    Query records pulled from user database instances.
    """
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        
        ttk.Label(self, text="🏆 GLOBAL LEADERBOARD", style="Header.TLabel").pack(pady=10)
        ttk.Label(self, text="Real-time rankings across all active systems & networks", style="Sub.TLabel").pack(pady=(0, 20))

        # Main List Table
        columns = ("Rank", "Username", "Score", "Category", "Difficulty", "Words Guess", "Date")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=12)
        
        # Setup column sizes
        self.tree.column("Rank", width=50, anchor=tk.CENTER)
        self.tree.column("Username", width=120, anchor=tk.W)
        self.tree.column("Score", width=80, anchor=tk.CENTER)
        self.tree.column("Category", width=110, anchor=tk.W)
        self.tree.column("Difficulty", width=100, anchor=tk.CENTER)
        self.tree.column("Words Guess", width=100, anchor=tk.CENTER)
        self.tree.column("Date", width=150, anchor=tk.CENTER)
        
        for col in columns:
            self.tree.heading(col, text=col)
            
        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.refresh_leaderboard_data()

        # Navigation menu
        ttk.Button(self, text="RETURN TO MAIN CONSOLE", command=master.show_menu_view, style="Action.TButton").pack(side=tk.BOTTOM, pady=10)

    def refresh_leaderboard_data(self):
        """Fetches and appends high-scores dataset details."""
        # Clear existing line lists
        for child in self.tree.get_children():
            self.tree.delete(child)
            
        if not self.master.db_connected:
            # Create a mock aesthetic leaderboard for guest mode
            mock_data = [
                ("Admin_Pro", 1200, "Technology", "hard", 3, "2026-06-15 12:00:00"),
                ("BetaGuesser", 850, "Sports", "medium", 4, "2026-06-16 09:30:00"),
                ("SyntaxWizard", 400, "Movies", "easy", 4, "2026-06-16 11:20:00"),
            ]
            for idx, r in enumerate(mock_data, 1):
                self.tree.insert("", tk.END, values=(idx, r[0], r[1], r[2], r[3], r[4], r[5]))
            return

        records = self.master.db.get_global_leaderboard(limit=15)
        for idx, item in enumerate(records, 1):
            date_str = item["played_at"].strftime("%Y-%m-%d %H:%M") if item["played_at"] else "N/A"
            self.tree.insert("", tk.END, values=(
                idx,
                item["username"],
                item["score"],
                item["category"],
                item["difficulty"].capitalize(),
                item["words_guessed"],
                date_str
            ))


class StatsFrame(ttk.Frame):
    """
    Renders user profile statistics and details analytics.
    Includes average point metrics, top categories, and total playtime records.
    """
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        
        ttk.Label(self, text="📊 GAMEPLAY ANALYTICS PROFILE", style="Header.TLabel").pack(pady=10)
        
        # Center layout stats grid
        stats_container = ttk.Frame(self, padding=20)
        stats_container.pack(fill=tk.BOTH, expand=True)

        # Retrieve statistics from user profile
        user = master.current_user
        if not user or user["user_id"] == 0:
            # Play guest mock statistics
            self.stats = {
                "total_games": 5,
                "total_score": 1450,
                "avg_score": 290.0,
                "total_words_guessed": 11,
                "preferred_category": "Technology (Guest)"
            }
        else:
            if master.db_connected:
                self.stats = master.db.get_user_analytics(user["user_id"])
            else:
                self.stats = {"total_games": 0, "total_score": 0, "avg_score": 0.0, "total_words_guessed": 0, "preferred_category": "N/A"}

        # Custom high-contrast stats panels layout (Bento Box style)
        grid = ttk.Frame(stats_container)
        grid.pack(anchor=tk.CENTER)
        
        self.add_bento_box(grid, 0, 0, "TOTAL ROUNDS PLAYED", str(self.stats["total_games"]), "#38BDF8")
        self.add_bento_box(grid, 0, 1, "CUMULATIVE SCORE", str(self.stats["total_score"]), "#10B981")
        self.add_bento_box(grid, 1, 0, "AVERAGE SCORE / ROUND", str(self.stats["avg_score"]), "#F59E0B")
        self.add_bento_box(grid, 1, 1, "TOTAL WORDS DECODED", str(self.stats["total_words_guessed"]), "#EC4899")
        
        # Horizontal category highlight bar
        preferred_lbl = ttk.Label(stats_container, text=f"PREFERRED TOP WORD CATEGORY: {self.stats['preferred_category'].upper()}",
                                  font=("Helvetica", 12, "bold"), foreground="#6366F1")
        preferred_lbl.pack(pady=20)

        # Back button
        ttk.Button(self, text="RETURN TO MAIN CONSOLE", command=master.show_menu_view, style="Action.TButton").pack(side=tk.BOTTOM, pady=10)

    def add_bento_box(self, parent, r, c, label, val_str, accent_color):
        # Create a colored frame mimicking card layout
        card = tk.Frame(parent, bg="#0F172A", bd=1, relief=tk.SOLID, width=220, height=130)
        card.grid(row=r, column=c, padx=10, pady=10)
        card.grid_propagate(False)
        
        tk.Label(card, text=label, fg="#94A3B8", bg="#0F172A", font=("Helvetica", 8, "bold")).pack(pady=(15, 2))
        tk.Label(card, text=val_str, fg=accent_color, bg="#0F172A", font=("Helvetica", 24, "bold")).pack(pady=5)


# Main Entry Runner guard
if __name__ == "__main__":
    app = SmartHangmanApp()
    # Handle DB clean-up on exit event
    def on_closing():
        if app.db_connected:
            app.db.close()
        app.destroy()
        
    app.protocol("WM_DELETE_WINDOW", on_closing)
    app.mainloop()
