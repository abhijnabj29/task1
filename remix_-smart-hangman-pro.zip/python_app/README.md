# Smart Hangman Pro
> Professional Desktop Gaming, User Authentication, and Analytics powered by Python OOP (Tkinter) and MySQL Relational Backends.

---

## 🚀 App Highlights & Architecture
*   **Highly Modular Architecture**: Separated cleanly into Words DB, MySQL Schema, Database connectors, and structural Tkinter main layouts.
*   **User Sessions Management**: Includes registration and login forms with SHA-256 secure hashing.
*   **Dual Mode Connectivity Engine**: Features an automatic network test that defaults to "Offline Play/Guest Mode" if local or remote MySQL servers are unreachable.
*   **Stretching Word Lists Database**: Covers Technology, Sports, Animals, and Movies topics across Easy, Medium, and Hard tiers, complete with hints.
*   **Fluid Vector Painter Canvas**: Progressively paints the hangman stick figure with full pixel layout safety.
*   **Sound Synthesis & Audio feedback**: Built-in beep tones for guessing actions.
*   **Global Scoreboard Logs**: Tracks real-time top scores and players.
*   **Interactive Analytics Panels**: Custom-built stats dashboard.

---

## 🛠️ Installation & Launch

### Prerequisite Dependencies
- **Python 3.8+**
- **MySQL / MariaDB Server**

### Step 1: Install Python Connector
Open your command terminal and execute:
```bash
pip install mysql-connector-python
```

### Step 2: Set up MySQL Database Schema
1. Start your MySQL Server admin interface.
2. Run the SQL statements inside `schema.sql`. You can execute it via command line:
   ```bash
   mysql -u root -p < schema.sql
   ```
   *(By default, the script creates a schema named `smarthangman_db` and seeds it with mock test user accounts, passwords hash, and gameplay records.)*

### Step 3: Run the Python Applet
Simply launch `main.py` using Python:
```bash
python main.py
```
*(If your MySQL database requires custom connection setups like passwords or remote hosts, navigate to `database.py` and modify the default parameters in the `__init__` constructor of `DatabaseManager`.)*

---

## 👥 Seed Profiles (Test Accounts)
The schema seeds the database with three pre-made user profiles, all configured with the password `pass123`.

1.  **SpeedyGuesser** (Password: `pass123`)
2.  **TechWizard** (Password: `pass123`)
3.  **HangmanPro** (Password: `pass123`)

---

## 📁 File Structure Map
*   📁 `python_app/`
    *   `main.py` - Core Tkinter graphical engine, view layouts, canvas vector drawing, and controller bindings.
    *   `database.py` - Secure database connections, logins query executions, stats logs, and leaderboard compilation.
    *   `words.py` - Standard categorized dictionary containing words, hints, and difficulty configurations.
    *   `schema.sql` - Complete, executable SQL script to initialize tables, indexes, and fake test data.
    *   `PROJECT_REPORT.md` - Complete academic report containing class breakdowns, flowcharts, ER diagrams, and system models.
    *   `README.md` - Getting-started configurations guide.
