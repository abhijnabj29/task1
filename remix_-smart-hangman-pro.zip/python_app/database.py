# database.py
# Part of Smart Hangman Pro
# Handles all communication with the MySQL database under an Object-Oriented paradigm.

import mysql.connector
from mysql.connector import Error
import hashlib

class DatabaseManager:
    """
    Manages database persistent storage, authentication, scores, and statistics.
    Encapsulates all SQL logic inside highly reusable and secure OOP methods.
    """
    def __init__(self, host="localhost", user="root", password="", database="smarthangman_db"):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.connection = None
        self.cursor = None

    def connect(self):
        """Establishes a connection to the MySQL database."""
        try:
            # First attempt connecting without default database to create it if missing
            temp_conn = mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password
            )
            temp_cursor = temp_conn.cursor()
            temp_cursor.execute(f"CREATE DATABASE IF NOT EXISTS {self.database}")
            temp_cursor.close()
            temp_conn.close()

            # Now connect to the targeted database
            self.connection = mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database
            )
            self.cursor = self.connection.cursor(dictionary=True)
            self.create_tables()
            return True
        except Error as e:
            print(f"Database Connection Error: {e}")
            return False

    def close(self):
        """Safely closes active cursors and connections."""
        if self.cursor:
            self.cursor.close()
        if self.connection and self.connection.is_connected():
            self.connection.close()

    def create_tables(self):
        """Initializes tables, indexes, and constraints representing the application schema."""
        users_table = """
        CREATE TABLE IF NOT EXISTS users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(64) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;
        """
        
        scores_table = """
        CREATE TABLE IF NOT EXISTS scores (
            score_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            score INT NOT NULL DEFAULT 0,
            category VARCHAR(30) NOT NULL,
            difficulty VARCHAR(15) NOT NULL,
            words_guessed INT NOT NULL DEFAULT 0,
            played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            INDEX idx_user_score (user_id, score),
            INDEX idx_leaderboard (score DESC, played_at ASC)
        ) ENGINE=InnoDB;
        """
        
        try:
            self.cursor.execute(users_table)
            self.cursor.execute(scores_table)
            self.connection.commit()
        except Error as e:
            print(f"Failed to create schema tables: {e}")

    def _hash_password(self, password):
        """Helper method to securely hash passwords before database storage."""
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def register_user(self, username, password):
        """
        Registers a new user inside the database.
        Returns (success_boolean, message) after integrity check.
        """
        if not username or not password:
            return False, "Username and password cannot be empty."
        if len(username) < 3:
            return False, "Username must be at least 3 characters."
        if len(password) < 4:
            return False, "Password must be at least 4 characters."

        pwd_hash = self._hash_password(password)
        query = "INSERT INTO users (username, password_hash) VALUES (%s, %s)"
        try:
            self.cursor.execute(query, (username, pwd_hash))
            self.connection.commit()
            return True, "User registered successfully!"
        except Error as e:
            if e.errno == 1062:  # Duplicate entry error code in MySQL
                return False, f"Username '{username}' is already taken."
            return False, f"Database Error: {e.msg}"

    def authenticate_user(self, username, password):
        """
        Authenticates an existing user and returns their profile details if successful.
        Returns (success_boolean, user_record_dict_or_message)
        """
        if not username or not password:
            return False, "Username and password are required."

        pwd_hash = self._hash_password(password)
        query = "SELECT user_id, username FROM users WHERE username = %s AND password_hash = %s"
        try:
            self.cursor.execute(query, (username, pwd_hash))
            user = self.cursor.fetchone()
            if user:
                return True, user
            return False, "Invalid username or password credentials."
        except Error as e:
            return False, f"Database Error: {e.msg}"

    def record_score(self, user_id, score, category, difficulty, words_guessed):
        """
        Saves a finished game session statistics for high scores and analytic logging.
        Returns success status.
        """
        query = """
        INSERT INTO scores (user_id, score, category, difficulty, words_guessed)
        VALUES (%s, %s, %s, %s, %s)
        """
        try:
            self.cursor.execute(query, (user_id, score, category, difficulty, words_guessed))
            self.connection.commit()
            return True
        except Error as e:
            print(f"Failed to save score statistics: {e}")
            return False

    def get_global_leaderboard(self, limit=10):
        """
        Fetches best high-scores globally. Combines scores for unified leaderboard ranking.
        """
        query = """
        SELECT u.username, s.score, s.category, s.difficulty, s.words_guessed, s.played_at
        FROM scores s
        INNER JOIN users u ON s.user_id = u.user_id
        ORDER BY s.score DESC, s.played_at ASC
        LIMIT %s
        """
        try:
            self.cursor.execute(query, (limit,))
            return self.cursor.fetchall()
        except Error as e:
            print(f"Leaderboard fetch failure: {e}")
            return []

    def get_user_analytics(self, user_id):
        """
        Computes interactive user analytics (average score, game counts, top category, total score) 
        for personalized profile dashboards.
        """
        stats = {
            "total_games": 0,
            "total_score": 0,
            "avg_score": 0.0,
            "total_words_guessed": 0,
            "preferred_category": "N/A"
        }
        
        # 1. Basic aggregates
        agg_query = """
        SELECT 
            COUNT(*) as total_games,
            SUM(score) as total_score,
            AVG(score) as avg_score,
            SUM(words_guessed) as total_words_guessed
        FROM scores
        WHERE user_id = %s
        """
        # 2. Preferred category aggregate
        cat_query = """
        SELECT category, COUNT(*) as cat_count
        FROM scores
        WHERE user_id = %s
        GROUP BY category
        ORDER BY cat_count DESC
        LIMIT 1
        """
        
        try:
            self.cursor.execute(agg_query, (user_id,))
            agg_result = self.cursor.fetchone()
            if agg_result and agg_result["total_games"] > 0:
                stats["total_games"] = agg_result["total_games"]
                stats["total_score"] = int(agg_result["total_score"] or 0)
                stats["avg_score"] = round(float(agg_result["avg_score"] or 0.0), 1)
                stats["total_words_guessed"] = int(agg_result["total_words_guessed"] or 0)
                
                # Fetch category preference
                self.cursor.execute(cat_query, (user_id,))
                cat_result = self.cursor.fetchone()
                if cat_result:
                    stats["preferred_category"] = cat_result["category"]
            return stats
        except Error as e:
            print(f"Failed to compile user statistics: {e}")
            return stats
