# Project Report: Smart Hangman Pro
*Academic & Professional Development Software Project Milestone*

---

## 1. Executive Summary

**Smart Hangman Pro** is a modern, professional-grade desktop iteration of the classic word-deduction game. Engineered using **Python 3.x** and **Tkinter (GUI)** coupled with a robust relational backend utilizing **MySQL Server**, this application marries the simplicity of classical retro games with advanced operational architecture. Emphasizing high-standard Object-Oriented Programming (OOP) methodologies, the workspace leverages multi-layered database persistence, comprehensive player analytics, cryptographic user authentication shields, dynamic vector rendering animations, and interactive multimedia sound synthesizers.

---

## 2. Requirements & Specification

### 2.1 Functional Requirements
1. **User Accounts & Session Tracking**: Cryptographically protected (SHA-256) Login/Registration gates to maintain session integrity. Contains a fail-safe Offline/Guest mode bypassed if relational database servers are down.
2. **Interactive Gameplay Deck**: Random word choosing algorithm matching user-defined word categories (Technology, Sports, Movies, Animals) and granular difficulties (Easy, Medium, Hard). Includes customizable hints mapped per word.
3. **Responsive Visual Rig**: An interactive vector animation canvas rendering the hangman gallows progressively on incorrect guesses.
4. **Leaderboard Tracking & High Scores**: Unified scoreboard showing rank, custom names, final counts, categories, and timestamps pulling records from connected database.
5. **Insights & Analytics Dashboards**: Interactive metrics (cumulative points, total played rounds, success metrics, and preferred subjects tracking) dynamically updating per player profile.

### 2.2 System Architecture
```
    +-------------------------------------------------------+
    |                    USER UI LAYER                      |
    |                   (Tkinter Client)                    |
    +-------------------------------------------------------+
                                |
                                v
    +-------------------------------------------------------+
    |                  CONTROLLER MODULE                    |
    |               (Object-Oriented Engine)                |
    +-------------------------------------------------------+
                                |
            +-------------------+-------------------+
            |                                       |
            v                                       v
+-------------------------+             +-------------------------+
|     LOCAL DATABASE      |             |  AUDIO SYNTHESIZER ENGINE|
|    (MySQL Connector)    |             |   (Winsound / OS Bell)  |
+-------------------------+             +-------------------------+
            |
            v
+-------------------------+
|     MYSQL DB INSTANCE   |
|     (Tables/Indexes)    |
+-------------------------+
```

---

## 3. Object-Oriented Design & Patterns

The program is architected utilizing modular Encapsulation and Separation of Concerns (SoC) principles, mapped into distinct cohesive components:

### 3.1 Class Architecture
1. **`DatabaseManager`** (`database.py`): Encapsulates everything related to network storage, credentials checking, transactions, metrics compiling, and schemas creation. Zero SQL leakage occurs inside UI views.
2. **`SmartHangmanApp`** (`main.py`): The main controller coordinating frame transitions, audio synthesis routing, and system parameters tracking.
3. **`AuthFrame`**, **`MenuFrame`**, **`GamePlayFrame`**, **`LeaderboardFrame`**, **`StatsFrame`**: Specialized UI component classes inheriting from standard `ttk.Frame`, keeping rendering logic completely isolated.
4. **`WORD_DATABASE`** (`words.py`): Encapsulates word datasets, difficulty ranges, and hinting metadata in structured dictionaries.

---

## 4. Entity-Relationship (ER) Diagram

A relational entity framework tracking players progress. Contains optimal indexes to accelerate top rankings.

```
       +------------------+                   +--------------------+
       |      USERS       |                   |       SCORES       |
       +------------------+                   +--------------------+
       | PK | user_id     |<----------------- | PK | score_id      |
       |    | username    | (1 to Many Rel)   | FK | user_id       |
       |    | pwd_hash    |                   |    | score         |
       |    | created_at  |                   |    | category      |
       +------------------+                   |    | difficulty    |
                                              |    | words_guessed |
                                              |    | played_at     |
                                              +--------------------+
```

### Attributes & Data Directory Structure
*   **`users` Table**:
    *   `user_id` (INT, Primary Key, Auto-Incrementing): Unique identifier.
    *   `username` (VARCHAR(50), Unique, Not Null): Handles player displays (minimum 3 chars restriction).
    *   `password_hash` (VARCHAR(64), Not Null): Cryptographic SHA-256 hash representation of user's password.
    *   `created_at` (TIMESTAMP): Account registration timestamp.
*   **`scores` Table**:
    *   `score_id` (INT, Primary Key, Auto-Incrementing): Unique score identifier.
    *   `user_id` (INT, Foreign Key referencing `users(user_id)` ON DELETE CASCADE): Maps scores back to players.
    *   `score` (INT, Default 0): Point score.
    *   `category` (VARCHAR(30)): Category chosen (e.g. Technology).
    *   `difficulty` (VARCHAR(15)): Selected level (easy, medium, hard).
    *   `words_guessed` (INT, Default 0): Total consecutively solved words during active session.
    *   `played_at` (TIMESTAMP): Time of logging.

---

## 5. Flowchart & State Loop Grid

The game controller flow map follows execution steps:

```
                  [ APP LAUNCH ]
                         |
                         v
                [ Connect MySQL? ]
               /                \
         (Yes) /                  \ (No)
              v                    v
      [ Auth Front-End ]     [ Bypass Warning ]
      | Login/Register |           |
      \________________/           v
               \             [ Guest Session ]
                \                  /
                 v                v
             [ Main Navigation Console ]
             - Choose Category & Difficulty
             - Access Analytics/Scores
                         |
                         v
                [ Active Gameplay ]
                         |
                         v
                [ Load Word & Paint ]
             _/          |          \_
     (Letter Guess)   (Hint Request)   (Skip/Exit)
           |             |               |
           v             v               v
     [ Correct? ]   [ Reveal Hint ]  [ Conclude ]
      /        \     (Score Penalty)     |
    (Yes)      (No)                      |
     /            \                      |
    v              v                     |
[ Display ]   [ Chalk Off ]              |
    |          |                         |
[ All OK? ]   [ Dead? ]                  |
  |             |                        v
 (Yes)         (Yes)            [ Write Score MySQL ]
  |             |               (If Connection Active)
  v             v                        |
[ WIN ]       [ LOSE ]                   v
  \_____________/               [ Exit to Console Menu ]
         |
         v
[ Play Another? ]
 (Yes => Load Next Word)
 (No  => Conclude Session)
```

---

## 6. Testing & Exception Control

The application is built with comprehensive error checking and resilience against failure cases:
1.  **Empty / Short Fields Inputs**: Username and passwords length thresholds are checked during registration.
2.  **Duplicate Names Conflict**: SQLException catching interceptor intercepts Error Code `1062` (duplicate database entries), returning clear feedback rather than crashing.
3.  **Missing DB Fallback Driver**: Transparently transitions to an offline guest state, providing simulated leaderboards and local game profiles seamlessly.
4.  **Hardware Sound Issues Fail-safe**: Sound triggers are wrapped inside standard validation try-except gates, preventing systems lacking audio drivers from raising runtime errors.
5.  **Exhausted Words List Shuffler**: Prevents crashes or blank states during long gameplay streaks by auto-resetting structural lists once all items have been decoded.
