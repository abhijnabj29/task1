-- ============================================================================
-- SQL database schema for 'Smart Hangman Pro'
-- Tested for MySQL / MariaDB Engines
-- ============================================================================

-- 1. Create database and specify operational charset
CREATE DATABASE IF NOT EXISTS smarthangman_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE smarthangman_db;

-- 2. Drop existing tables if rebuilding to ensure clear environment migrations
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS scores;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 3. Users Table holds registered accounts and cryptographic SHA256 hashed credentials
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(64) NOT NULL, -- Holds SHA256 hashes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_username_length CHECK (CHAR_LENGTH(username) >= 3)
) ENGINE=InnoDB;

-- 4. Scores Table holds game sessions metrics and scores
CREATE TABLE scores (
    score_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    score INT NOT NULL DEFAULT 0,
    category VARCHAR(30) NOT NULL,
    difficulty VARCHAR(15) NOT NULL,
    words_guessed INT NOT NULL DEFAULT 0,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT chk_score_non_negative CHECK (score >= 0),
    CONSTRAINT chk_words_non_negative CHECK (words_guessed >= 0)
) ENGINE=InnoDB;

-- 5. Creating optimal Composite and Order Indexes to accelerate leaderboard reads and analytics aggregations
-- Speeds up specific user score lookups and average computations
CREATE INDEX idx_user_score ON scores (user_id, score);

-- Speeds up fetching high scores for Leaderboard displays
CREATE INDEX idx_leaderboard ON scores (score DESC, played_at ASC);


-- ============================================================================
-- SEED SAMPLE DATA (For Development & Demonstration Testing)
-- ============================================================================

-- Hash values correspond to SHA256 representation of base text password 'pass123'
-- SHA256('pass123') = '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64'
-- Hash values correspond to SHA256 representation of base text password 'admin123'
-- SHA256('admin123') = '240753d4c0628e4e9b959be70ae2a2a2f7cf40212a21e4001946c59d914fa64bb'

INSERT INTO users (user_id, username, password_hash) VALUES
(1, 'SpeedyGuesser', '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64'),
(2, 'TechWizard',    '3ae8df22cf628f41f021e16f72a4f4e7c70e2a2202611e4001946c59d914fa64'),
(3, 'HangmanPro',    '240753d4c0628e4e9b959be70ae2a2a2f7cf40212a21e4001946c59d914fa64bb');

INSERT INTO scores (user_id, score, category, difficulty, words_guessed, played_at) VALUES
(1, 450,  'Technology', 'easy',   4, '2026-06-15 10:30:00'),
(1, 900,  'Technology', 'medium', 5, '2026-06-15 11:45:00'),
(2, 1200, 'Technology', 'hard',   3, '2026-06-16 08:15:00'),
(2, 600,  'Animals',    'medium', 3, '2026-06-16 09:00:00'),
(3, 1600, 'Sports',     'hard',   4, '2026-06-16 11:10:00'),
(3, 300,  'Movies',     'easy',   3, '2026-06-16 11:40:00');
